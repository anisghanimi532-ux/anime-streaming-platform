import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Heart, Star, Play, Plus } from 'lucide-react';

// Types
interface AnimeCardProps {
  anime: {
    mal_id: number;
    title: string;
    title_english?: string;
    title_japanese?: string;
    images: {
      jpg: {
        image_url: string;
        large_image_url: string;
      };
    };
    type: string;
    episodes?: number;
    status: string;
    score?: number;
    airing?: boolean;
    genres?: { name: string }[];
  };
  showStatus?: boolean;
  showAddButton?: boolean;
  onAddToList?: () => void;
}

export default function AnimeCard({
  anime,
  showStatus = true,
  showAddButton = false,
  onAddToList,
}: AnimeCardProps) {
  const { t } = useTranslation();

  const getStatusBadge = () => {
    if (!showStatus) return null;
    if (anime.airing) {
      return (
        <span className="absolute top-2 left-2 px-2 py-1 bg-[#22c55e] text-white text-xs font-semibold rounded-lg flex items-center gap-1">
          <Play className="w-3 h-3" />
          {t('anime.airing')}
        </span>
      );
    }
    if (anime.status === 'Finished Airing') {
      return (
        <span className="absolute top-2 left-2 px-2 py-1 bg-[#06b6d4] text-white text-xs font-semibold rounded-lg">
          {t('anime.finished')}
        </span>
      );
    }
    if (anime.status === 'Not Yet Aired') {
      return (
        <span className="absolute top-2 left-2 px-2 py-1 bg-[#f97316] text-white text-xs font-semibold rounded-lg">
          {t('anime.notAired')}
        </span>
      );
    }
    return null;
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-[#22c55e]';
    if (score >= 7) return 'bg-[#06b6d4]';
    if (score >= 6) return 'bg-[#f59e0b]';
    if (score >= 5) return 'bg-[#f97316]';
    return 'bg-[#ef4444]';
  };

  return (
    <Link
      to={`/anime/${anime.mal_id}`}
      className="anime-card group"
    >
      {/* Image */}
      <div className="relative aspect-[3/4] overflow-hidden rounded-xl">
        <img
          src={anime.images.jpg.image_url}
          alt={anime.title_english || anime.title}
          className="anime-card-image"
          loading="lazy"
        />
        <div className="anime-card-overlay" />

        {/* Score Badge */}
        {anime.score && (
          <div className={`absolute top-2 right-2 px-2 py-1 ${getScoreColor(anime.score)} text-white text-xs font-bold rounded-lg flex items-center gap-1`}>
            <Star className="w-3 h-3 fill-current" />
            {anime.score.toFixed(1)}
          </div>
        )}

        {/* Status Badge */}
        {getStatusBadge()}

        {/* Hover Overlay Content */}
        <div className="anime-card-content">
          {/* Genres */}
          {anime.genres && anime.genres.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {anime.genres.slice(0, 2).map((genre, index) => (
                <span
                  key={index}
                  className="px-2 py-0.5 bg-[#8b5cf6]/80 text-white text-xs rounded-full"
                >
                  {genre.name}
                </span>
              ))}
            </div>
          )}

          {/* Type Badge */}
          <div className="flex items-center justify-between">
            <span className="px-2 py-1 bg-[var(--color-bg-tertiary)] text-[var(--color-text)] text-xs font-semibold rounded-lg">
              {anime.type}
            </span>
            {anime.episodes && (
              <span className="text-xs text-[var(--color-text-secondary)]">
                {anime.episodes} {t('anime.episodes')}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="text-sm font-semibold text-[var(--color-text)] line-clamp-2 group-hover:text-[#8b5cf6] transition-colors">
          {anime.title_english || anime.title}
        </h3>
        <p className="text-xs text-[var(--color-text-secondary)] mt-1 line-clamp-1">
          {anime.title_japanese}
        </p>
      </div>

      {/* Add Button */}
      {showAddButton && onAddToList && (
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onAddToList();
          }}
          className="absolute top-2 right-2 p-2 bg-[#8b5cf6] rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-[#7c3aed]"
        >
          <Plus className="w-4 h-4 text-white" />
        </button>
      )}
    </Link>
  );
}
