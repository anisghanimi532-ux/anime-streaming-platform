import { Suspense } from 'react';
import { Outlet, useNavigation } from 'react-router-dom';

// Components
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import Loading from './Loading';

function Layout() {
  const navigation = useNavigation();
  const isLoading = navigation.state === 'loading';

  return (
    <div className="min-h-screen bg-[var(--color-bg)]">
      <Navbar />
      <Sidebar />
      <main className="pt-16 min-h-screen">
        <Suspense fallback={<Loading />}>
          <Outlet />
        </Suspense>
      </main>
      {isLoading && (
        <div className="fixed top-0 left-0 right-0 h-1 bg-[var(--color-bg-tertiary)] z-50">
          <div className="h-full bg-gradient-to-r from-[#06b6d4] to-[#8b5cf6] animate-pulse" />
        </div>
      )}
    </div>
  );
}

export default Layout;
