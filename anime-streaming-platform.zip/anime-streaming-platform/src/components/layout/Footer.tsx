// src/components/layout/Footer.tsx
import { Link } from 'react-router-dom';
import { Github, Twitter, Mail, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-[var(--color-border)] bg-[var(--color-bg-secondary)]/50 mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center">
                <span className="text-white font-bold text-xl">A</span>
              </div>
              <span className="text-xl font-bold gradient-text">AnimeHub</span>
            </div>
            <p className="text-[var(--color-text-secondary)] text-sm">
              Your favorite platform for watching anime. Enjoy the best anime experience with us.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/anime" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">Anime List</Link></li>
              <li><Link to="/movies" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">Movies</Link></li>
              <li><Link to="/new-episodes" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">New Episodes</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><Link to="/anime?genre=action" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">Action</Link></li>
              <li><Link to="/anime?genre=romance" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">Romance</Link></li>
              <li><Link to="/anime?genre=comedy" className="text-[var(--color-text-secondary)] hover:text-[#8b5cf6]">Comedy</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <div className="flex gap-4">
              <a href="#" className="p-2 rounded-lg bg-[var(--color-bg-secondary)] hover:bg-[#8b5cf6] transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-[var(--color-bg-secondary)] hover:bg-[#06b6d4] transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-[var(--color-bg-secondary)] hover:bg-[#f97316] transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-[var(--color-border)] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[var(--color-text-secondary)] text-sm">
            © 2024 AnimeHub. All rights reserved.
          </p>
          <p className="text-[var(--color-text-secondary)] text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500" /> using React & Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
}