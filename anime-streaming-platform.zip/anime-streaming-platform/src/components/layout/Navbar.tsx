// src/components/layout/Navbar.tsx
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useState } from 'react';
import {
  Menu, X, Search, User, LogOut, Settings, Heart,
  List, Clock, Sun, Moon, Globe, ChevronDown
} from 'lucide-react';
import { useThemeStore } from '../../stores/themeStore';
import { useAuthStore } from '../../stores/authStore';
import { authApi } from '../../lib/supabase';
import i18n from '../../i18n';

export default function Navbar() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { theme, setTheme } = useThemeStore();
  const { user, logout } = useAuthStore();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const handleLogout = async () => {
    await authApi.signOut();
    logout();
    navigate('/');
    setIsProfileOpen(false);
  };

  const toggleLanguage = (lang: string) => {
    i18n.changeLanguage(lang);
    localStorage.setItem('language', lang);
    setIsLangOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-[var(--color-bg)]/95 backdrop-blur-md border-b border-[var(--color-border)]">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <span className="text-xl font-bold gradient-text hidden sm:block">AnimeHub</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-6">
            <Link to="/" className="nav-pill-primary">
              <span className="text-lg">🏠</span> {t('nav.home')}
            </Link>
            <Link to="/new-episodes" className="nav-pill-secondary">
              <span className="text-lg">▶️</span> {t('nav.newEpisodes')}
            </Link>
            <Link to="/anime" className="nav-pill-tertiary">
              <span className="text-lg">📺</span> {t('nav.anime')}
            </Link>
            <Link to="/movies" className="nav-pill-quaternary">
              <span className="text-lg">🎬</span> {t('nav.movies')}
            </Link>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Search Button */}
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 rounded-lg hover:bg-[var(--color-bg-secondary)] transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Language Toggle */}
            <div className="relative">
              <button
                onClick={() => setIsLangOpen(!isLangOpen)}
                className="p-2 rounded-lg hover:bg-[var(--color-bg-secondary)] transition-colors flex items-center gap-1"
              >
                <Globe className="w-5 h-5" />
                <span className="text-xs">{i18n.language.toUpperCase()}</span>
              </button>
              {isLangOpen && (
                <div className="absolute right-0 mt-2 w-32 bg-[var(--color-card)] border border-[var(--color-border)] rounded-xl shadow-xl overflow-hidden">
                  <button
                    onClick={() => toggleLanguage('ar')}
                    className="w-full px-4 py-2 text-right hover:bg-[var(--color-bg-secondary)] flex items-center gap-2"
                  >
                    🇸🇦 العربية
                  </button>
                  <button
                    onClick={() => toggleLanguage('en')}
                    className="w-full px-4 py-2 text-right hover:bg-[var(--color-bg-secondary)] flex items-center gap-2"
                  >
                    🇬🇧 English
                  </button>
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-lg hover:bg-[var(--color-bg-secondary)] transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* User Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-[var(--color-bg-secondary)] transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <ChevronDown className="w-4 h-4" />
                </button>
                {isProfileOpen && (
                  <div className="dropdown-menu">
                    <Link
                      to="/profile"
                      onClick={() => setIsProfileOpen(false)}
                      className="dropdown-item"
                    >
                      <User className="w-4 h-4" /> {t('nav.profile')}
                    </Link>
                    <Link
                      to="/my-list"
                      onClick={() => setIsProfileOpen(false)}
                      className="dropdown-item"
                    >
                      <List className="w-4 h-4" /> {t('nav.myList')}
                    </Link>
                    <Link
                      to="/favorites"
                      onClick={() => setIsProfileOpen(false)}
                      className="dropdown-item"
                    >
                      <Heart className="w-4 h-4" /> {t('nav.favorites')}
                    </Link>
                    <Link
                      to="/history"
                      onClick={() => setIsProfileOpen(false)}
                      className="dropdown-item"
                    >
                      <Clock className="w-4 h-4" /> {t('nav.history')}
                    </Link>
                    <hr className="border-[var(--color-border)] my-2" />
                    <button
                      onClick={handleLogout}
                      className="dropdown-item w-full text-left text-red-500"
                    >
                      <LogOut className="w-4 h-4" /> {t('nav.logout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="btn-primary hidden sm:flex"
              >
                {t('nav.login')}
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-[var(--color-bg-secondary)] transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {isSearchOpen && (
          <div className="py-4 border-t border-[var(--color-border)]">
            <form onSubmit={handleSearch} className="search-bar">
              <button type="submit" className="absolute left-6 top-1/2 -translate-y-1/2">
                <Search className="w-6 h-6" />
              </button>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('home.searchPlaceholder')}
                className="search-input"
                autoFocus
              />
            </form>
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-[var(--color-border)]">
            <div className="flex flex-col gap-2">
              <Link
                to="/"
                onClick={() => setIsMenuOpen(false)}
                className="nav-pill-primary w-full justify-center"
              >
                {t('nav.home')}
              </Link>
              <Link
                to="/new-episodes"
                onClick={() => setIsMenuOpen(false)}
                className="nav-pill-secondary w-full justify-center"
              >
                {t('nav.newEpisodes')}
              </Link>
              <Link
                to="/anime"
                onClick={() => setIsMenuOpen(false)}
                className="nav-pill-tertiary w-full justify-center"
              >
                {t('nav.anime')}
              </Link>
              <Link
                to="/movies"
                onClick={() => setIsMenuOpen(false)}
                className="nav-pill-quaternary w-full justify-center"
              >
                {t('nav.movies')}
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}