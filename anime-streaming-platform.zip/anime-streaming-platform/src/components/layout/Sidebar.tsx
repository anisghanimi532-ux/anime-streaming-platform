// src/components/layout/Sidebar.tsx
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Home, Play, Tv, Film, List, Heart, Clock, User, Bookmark } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

export default function Sidebar() {
  const { t } = useTranslation();
  const location = useLocation();
  const { isAuthenticated } = useAuthStore();

  const navItems = [
    { path: '/', icon: Home, label: t('nav.home') },
    { path: '/new-episodes', icon: Play, label: t('nav.newEpisodes') },
    { path: '/anime', icon: Tv, label: t('nav.anime') },
    { path: '/movies', icon: Film, label: t('nav.movies') },
  ];

  const userItems = isAuthenticated ? [
    { path: '/my-list', icon: List, label: t('nav.myList') },
    { path: '/favorites', icon: Heart, label: t('nav.favorites') },
    { path: '/history', icon: Clock, label: t('nav.history') },
    { path: '/profile', icon: User, label: t('nav.profile') },
  ] : [];

  return (
    <aside className="hidden lg:block w-64 shrink-0 border-r border-[var(--color-border)] bg-[var(--color-bg-secondary)]/50">
      <div className="sticky top-16 p-4 space-y-6">
        {/* Main Navigation */}
        <div>
          <h3 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase mb-3 px-4">
            {t('nav.home')}
          </h3>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    isActive
                      ? 'bg-[#8b5cf6] text-white shadow-lg'
                      : 'hover:bg-[var(--color-bg-secondary)]'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* User Navigation */}
        {userItems.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase mb-3 px-4">
              {t('nav.myList')}
            </h3>
            <nav className="space-y-1">
              {userItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive
                        ? 'bg-[#06b6d4] text-white shadow-lg'
                        : 'hover:bg-[var(--color-bg-secondary)]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}

        {/* Genres Quick Access */}
        <div>
          <h3 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase mb-3 px-4">
            {t('anime.genres')}
          </h3>
          <div className="flex flex-wrap gap-2 px-4">
            {['Action', 'Romance', 'Comedy', 'Sci-Fi', 'Horror', 'Fantasy'].map((genre) => (
              <Link
                key={genre}
                to={`/anime?genre=${genre}`}
                className="genre-pill text-xs"
              >
                {genre}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}