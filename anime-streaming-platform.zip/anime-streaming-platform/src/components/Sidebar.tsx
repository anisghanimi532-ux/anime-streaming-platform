import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  X,
  Home,
  Play,
  List,
  Film,
  TrendingUp,
  Star,
  Clock,
  Heart,
  Search,
  Filter,
} from 'lucide-react';

// Store
import { useUIStore } from '../lib/store';

const genres = [
  { id: 1, name: 'Action', icon: '⚔️' },
  { id: 2, name: 'Adventure', icon: '🗺️' },
  { id: 4, name: 'Comedy', icon: '😂' },
  { id: 8, name: 'Drama', icon: '🎭' },
  { id: 10, name: 'Fantasy', icon: '🔮' },
  { id: 14, name: 'Horror', icon: '👻' },
  { id: 7, name: 'Mystery', icon: '🔍' },
  { id: 22, name: 'Romance', icon: '💕' },
  { id: 24, name: 'Sci-Fi', icon: '🚀' },
  { id: 36, name: 'Slice of Life', icon: '🌸' },
  { id: 30, name: 'Sports', icon: '⚽' },
  { id: 37, name: 'Supernatural', icon: '👹' },
];

function Sidebar() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { sidebarOpen, toggleSidebar } = useUIStore();

  const menuItems = [
    { path: '/', icon: Home, label: t('nav.home'), gradient: 'from-[#22c55e] to-[#06b6d4]' },
    { path: '/?status=airing', icon: Play, label: t('nav.newEpisodes'), gradient: 'from-[#06b6d4] to-[#6366f1]' },
    { path: '/anime', icon: List, label: t('nav.animeList'), gradient: 'from-[#f97316] to-[#f59e0b]' },
    { path: '/movies', icon: Film, label: t('nav.movies'), gradient: 'from-[#8b5cf6] to-[#ec4899]' },
    { path: '/anime?order_by=popularity', icon: TrendingUp, label: t('nav.trending'), gradient: 'from-[#ef4444] to-[#f97316]' },
    { path: '/anime?order_by=score', icon: Star, label: t('nav.topRated'), gradient: 'from-[#eab308] to-[#84cc16]' },
    { path: '/anime?status=upcoming', icon: Clock, label: t('nav.latest'), gradient: 'from-[#06b6d4] to-[#8b5cf6]' },
  ];

  const handleGenreClick = (genreId: number) => {
    navigate(`/anime?genre=${genreId}`);
    toggleSidebar();
  };

  return (
    <>
      {/* Backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-16 left-0 bottom-0 w-80 bg-[var(--color-bg-secondary)] z-40 transform transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-[var(--color-border)]">
            <h2 className="text-lg font-semibold text-[var(--color-text)]">
              {t('nav.search')}
            </h2>
            <button
              onClick={toggleSidebar}
              className="p-2 rounded-lg hover:bg-[var(--color-bg-tertiary)] transition-colors lg:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="p-4 space-y-2">
            <div className="mb-6">
              <h3 className="text-sm font-medium text-[var(--color-text-secondary)] mb-3 px-4">
                Navigation
              </h3>
              <div className="space-y-1">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  return (
                    <button
                      key={item.path}
                      onClick={() => {
                        navigate(item.path);
                        toggleSidebar();
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                        isActive
                          ? `bg-gradient-to-r ${item.gradient} text-white shadow-lg`
                          : 'text-[var(--color-text)] hover:bg-[var(--color-bg-tertiary)]'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Genres */}
            <div>
              <h3 className="text-sm font-medium text-[var(--color-text-secondary)] mb-3 px-4 flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Genres
              </h3>
              <div className="grid grid-cols-2 gap-2 px-2">
                {genres.map((genre) => (
                  <button
                    key={genre.id}
                    onClick={() => handleGenreClick(genre.id)}
                    className="flex items-center gap-2 px-3 py-2 bg-[var(--color-bg-tertiary)] rounded-lg text-sm text-[var(--color-text)] hover:bg-[#8b5cf6]/20 hover:text-[#8b5cf6] transition-colors"
                  >
                    <span>{genre.icon}</span>
                    <span className="truncate">{genre.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </nav>
        </div>
      </aside>
    </>
  );
}

export default Sidebar;
