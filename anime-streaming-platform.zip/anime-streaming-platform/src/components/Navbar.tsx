import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Menu,
  X,
  Sun,
  Moon,
  Globe,
  User,
  LogOut,
  Heart,
  List,
  History,
  ChevronDown,
  Play,
  TrendingUp,
} from 'lucide-react';

// Store
import { useAuthStore, useThemeStore } from '../lib/store';

// Supabase
import { authApi } from '../lib/supabase';

function Navbar() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { user, logout, isAuthenticated } = useAuthStore();
  const { theme, setTheme, language, setLanguage } = useThemeStore();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search/${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
  };

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
  };

  const handleLogout = async () => {
    await authApi.signOut();
    logout();
    setIsUserMenuOpen(false);
    navigate('/');
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[var(--color-bg)]/95 backdrop-blur-lg shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#8b5cf6] flex items-center justify-center">
              <Play className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text hidden sm:block">
              AnimeStream
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-6">
            <Link
              to="/"
              className="text-[var(--color-text)] hover:text-[#06b6d4] transition-colors"
            >
              {t('nav.home')}
            </Link>
            <Link
              to="/anime"
              className="text-[var(--color-text)] hover:text-[#06b6d4] transition-colors"
            >
              {t('nav.animeList')}
            </Link>
            <Link
              to="/movies"
              className="text-[var(--color-text)] hover:text-[#06b6d4] transition-colors"
            >
              {t('nav.movies')}
            </Link>
            <Link
              to="/search"
              className="text-[var(--color-text)] hover:text-[#06b6d4] transition-colors"
            >
              {t('nav.trending')}
            </Link>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('nav.searchPlaceholder')}
                className="w-full pl-10 pr-4 py-2 bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-full text-[var(--color-text)] placeholder-[var(--color-text-secondary)] focus:outline-none focus:border-[#8b5cf6]"
              />
            </div>
          </form>

          {/* Right Actions */}
          <div className="flex items-center gap-3">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-[var(--color-bg-secondary)] transition-colors"
              title={theme === 'dark' ? t('theme.light') : t('theme.dark')}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-yellow-400" />
              ) : (
                <Moon className="w-5 h-5 text-[#8b5cf6]" />
              )}
            </button>

            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className="p-2 rounded-full hover:bg-[var(--color-bg-secondary)] transition-colors flex items-center gap-1"
            >
              <Globe className="w-5 h-5 text-[var(--color-text)]" />
              <span className="text-sm font-medium">{language.toUpperCase()}</span>
            </button>

            {/* User Menu */}
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1 rounded-full hover:bg-[var(--color-bg-secondary)] transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <ChevronDown className="w-4 h-4 text-[var(--color-text)]" />
                </button>

                {isUserMenuOpen && (
                  <div className="dropdown-menu animate-fade-in">
                    <Link
                      to="/profile"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="dropdown-item"
                    >
                      <User className="w-5 h-5" />
                      {t('nav.profile')}
                    </Link>
                    <Link
                      to="/my-list"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="dropdown-item"
                    >
                      <List className="w-5 h-5" />
                      {t('nav.myList')}
                    </Link>
                    <Link
                      to="/favorites"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="dropdown-item"
                    >
                      <Heart className="w-5 h-5" />
                      {t('nav.favorites')}
                    </Link>
                    <Link
                      to="/history"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="dropdown-item"
                    >
                      <History className="w-5 h-5" />
                      {t('nav.watchHistory')}
                    </Link>
                    <div className="border-t border-[var(--color-border)]" />
                    <button
                      onClick={handleLogout}
                      className="dropdown-item w-full text-left text-red-500"
                    >
                      <LogOut className="w-5 h-5" />
                      {t('nav.logout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  to="/login"
                  className="px-4 py-2 text-[var(--color-text)] hover:text-[#8b5cf6] transition-colors"
                >
                  {t('nav.login')}
                </Link>
                <Link
                  to="/register"
                  className="btn-primary text-sm"
                >
                  {t('nav.register')}
                </Link>
              </div>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-full hover:bg-[var(--color-bg-secondary)] transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-[var(--color-border)] animate-fade-in">
            <form onSubmit={handleSearch} className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-secondary)]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('nav.searchPlaceholder')}
                  className="w-full pl-10 pr-4 py-3 bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl text-[var(--color-text)] placeholder-[var(--color-text-secondary)] focus:outline-none focus:border-[#8b5cf6]"
                />
              </div>
            </form>
            <div className="flex flex-col gap-2">
              <Link
                to="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-4 py-3 hover:bg-[var(--color-bg-secondary)] rounded-lg transition-colors"
              >
                {t('nav.home')}
              </Link>
              <Link
                to="/anime"
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-4 py-3 hover:bg-[var(--color-bg-secondary)] rounded-lg transition-colors"
              >
                {t('nav.animeList')}
              </Link>
              <Link
                to="/movies"
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-4 py-3 hover:bg-[var(--color-bg-secondary)] rounded-lg transition-colors"
              >
                {t('nav.movies')}
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
