export default function Loading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 border-4 border-[#8b5cf6]/20 rounded-full" />
          <div className="absolute inset-0 border-4 border-t-[#8b5cf6] border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin" />
          <div className="absolute inset-2 border-4 border-t-[#06b6d4] border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin-reverse" />
        </div>
        <p className="text-[var(--color-text-secondary)] font-medium animate-pulse">
          Loading...
        </p>
      </div>
    </div>
  );
}
