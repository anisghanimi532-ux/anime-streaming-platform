import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// i18n
import './lib/i18n';

// Layout
import Layout from './components/Layout';

// Pages
import Home from './pages/Home';
import AnimeList from './pages/AnimeList';
import AnimeDetail from './pages/AnimeDetail';
import Watch from './pages/Watch';
import Movies from './pages/Movies';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import MyList from './pages/MyList';
import Favorites from './pages/Favorites';
import History from './pages/History';
import Search from './pages/Search';
import NotFound from './pages/NotFound';

// Components
import Loading from './components/Loading';

import App from './App.tsx';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 2,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

const routes = [
  {
    path: '/',
    element: <Layout />,
    children: [
      { path: '/', element: <Home /> },
      { path: '/anime', element: <AnimeList /> },
      { path: '/anime/:id', element: <AnimeDetail /> },
      { path: '/anime/:id/episode/:episode', element: <Watch /> },
      { path: '/movies', element: <Movies /> },
      { path: '/login', element: <Login /> },
      { path: '/register', element: <Register /> },
      { path: '/profile', element: <Profile /> },
      { path: '/my-list', element: <MyList /> },
      { path: '/favorites', element: <Favorites /> },
      { path: '/history', element: <History /> },
      { path: '/search', element: <Search /> },
      { path: '/search/:query', element: <Search /> },
      { path: '*', element: <NotFound /> },
    ],
  },
];

const router = createBrowserRouter(routes);

function AppWrapper() {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}

export default AppWrapper;
