import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  ChevronLeft,
  ChevronRight,
  Settings,
  Play,
  AlertCircle,
  Loader2,
} from 'lucide-react';

// API
import { animeApi } from '../lib/jikanApi';
import { videoServers } from '../lib/jikanApi';

// Store
import { useAuthStore, useHistoryStore } from '../lib/store';
import { historyApi } from '../lib/supabase';

// Components
import Loading from '../components/Loading';

export default function Watch() {
  const { t } = useTranslation();
  const { id, episode } = useParams<{ id: string; episode: string }>();
  const navigate = useNavigate();

  const [selectedServer, setSelectedServer] = useState('gogoanime');
  const [showServers, setShowServers] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const { user, isAuthenticated } = useAuthStore();
  const { addToHistory } = useHistoryStore();

  const animeId = parseInt(id || '0');
  const currentEpisode = parseInt(episode || '1');

  // Fetch anime details
  const { data: anime, isLoading: isLoadingAnime } = useQuery({
    queryKey: ['anime', animeId],
    queryFn: () => animeApi.getAnimeById(animeId),
    enabled: !!animeId,
  });

  // Handle video load
  const handleVideoLoad = () => {
    setIsLoading(false);
    if (isAuthenticated && user) {
      addToHistory(
        {
          mal_id: anime?.data.mal_id,
          title: anime?.data.title,
          title_english: anime?.data.title_english,
          images: anime?.data.images,
          type: anime?.data.type,
          episodes: anime?.data.episodes,
          status: anime?.data.status,
          score: anime?.data.score,
        },
        currentEpisode,
        0
      );
      historyApi.addToHistory(user.id, animeId, currentEpisode, 0);
    }
  };

  // Handle server change
  const handleServerChange = async (server: string) => {
    setSelectedServer(server);
    setIsLoading(true);
    setVideoUrl(null);
    setShowServers(false);

    // Simulate getting video URL from server
    // In production, this would call an API to get the actual video URL
    setTimeout(() => {
      setVideoUrl('about:blank');
      setIsLoading(false);
    }, 1000);
  };

  // Navigation
  const totalEpisodes = anime?.data.episodes || 1;
  const hasPrevious = currentEpisode > 1;
  const hasNext = currentEpisode < totalEpisodes;

  const goToEpisode = (ep: number) => {
    navigate(`/anime/${animeId}/episode/${ep}`);
  };

  if (isLoadingAnime) return <Loading />;

  const animeData = anime?.data;

  return (
    <div className="min-h-screen bg-black">
      {/* Top Bar */}
      <div className="bg-[var(--color-bg)] px-4 py-3 flex items-center justify-between">
        <Link
          to={`/anime/${animeId}`}
          className="flex items-center gap-2 text-[var(--color-text)] hover:text-[#8b5cf6] transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="font-medium">{animeData?.title_english || animeData?.title}</span>
        </Link>

        <div className="flex items-center gap-4">
          {/* Server Selector */}
          <div className="relative">
            <button
              onClick={() => setShowServers(!showServers)}
              className="flex items-center gap-2 px-4 py-2 bg-[var(--color-bg-secondary)] rounded-lg text-[var(--color-text)] hover:bg-[var(--color-bg-tertiary)] transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span>{t('player.selectServer')}</span>
            </button>

            {showServers && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-[var(--color-card)] border border-[var(--color-border)] rounded-xl shadow-xl z-20">
                {videoServers.map((server) => (
                  <button
                    key={server.name}
                    onClick={() => handleServerChange(server.name)}
                    className={`w-full px-4 py-3 text-left hover:bg-[var(--color-bg-secondary)] transition-colors first:rounded-t-xl last:rounded-b-xl ${
                      selectedServer === server.name ? 'bg-[#8b5cf6] text-white' : 'text-[var(--color-text)]'
                    }`}
                  >
                    <span className="mr-2">{server.icon}</span>
                    {server.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Video Player Container */}
      <div className="video-container" style={{ aspectRatio: '16/9' }}>
        {isLoading ? (
          <div className="absolute inset-0 flex items-center justify-center bg-[var(--color-bg)]">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-[#8b5cf6] animate-spin" />
              <p className="text-[var(--color-text-secondary)]">{t('common.loading')}</p>
            </div>
          </div>
        ) : videoUrl ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <AlertCircle className="w-16 h-16 text-[#f97316] mx-auto mb-4" />
              <p className="text-[var(--color-text)] text-lg font-medium mb-2">
                Video Source Unavailable
              </p>
              <p className="text-[var(--color-text-secondary)]">
                Please try another server or check back later.
              </p>
            </div>
          </div>
        ) : null}
      </div>

      {/* Episode Navigation */}
      <div className="bg-[var(--color-bg)] px-4 py-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between">
            <button
              onClick={() => goToEpisode(currentEpisode - 1)}
              disabled={!hasPrevious}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                hasPrevious
                  ? 'bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white'
                  : 'bg-[var(--color-bg-tertiary)] text-[var(--color-text-secondary)] opacity-50 cursor-not-allowed'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
              {t('player.previousEpisode')}
            </button>

            <div className="text-center">
              <p className="text-lg font-semibold text-[var(--color-text)]">
                {t('anime.episode')} {currentEpisode}
              </p>
              <p className="text-sm text-[var(--color-text-secondary)]">
                {animeData?.title_english || animeData?.title}
              </p>
            </div>

            <button
              onClick={() => goToEpisode(currentEpisode + 1)}
              disabled={!hasNext}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                hasNext
                  ? 'bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white'
                  : 'bg-[var(--color-bg-tertiary)] text-[var(--color-text-secondary)] opacity-50 cursor-not-allowed'
              }`}
            >
              {t('player.nextEpisode')}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Episode List */}
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-[var(--color-text)] mb-4">
              {t('player.episodeList')}
            </h3>
            <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto">
              {Array.from({ length: totalEpisodes }, (_, i) => i + 1).map((ep) => (
                <button
                  key={ep}
                  onClick={() => goToEpisode(ep)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    ep === currentEpisode
                      ? 'bg-[#8b5cf6] text-white'
                      : 'bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white'
                  }`}
                >
                  {ep}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
