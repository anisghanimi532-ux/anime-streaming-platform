import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  Filter,
  Grid,
  List as ListIcon,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';

// API
import { animeApi, genresApi } from '../lib/jikanApi';

// Components
import AnimeCard from '../components/AnimeCard';
import Loading from '../components/Loading';

export default function AnimeList() {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [page, setPage] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);

  // Get filter values from URL
  const type = searchParams.get('type') || '';
  const status = searchParams.get('status') || '';
  const genre = searchParams.get('genre') || '';
  const orderBy = searchParams.get('order_by') || 'popularity';
  const sort = searchParams.get('sort') || 'desc';

  // Fetch anime list
  const { data, isLoading, isError } = useQuery({
    queryKey: ['anime-list', page, type, status, genre, orderBy, sort],
    queryFn: () => animeApi.getFullAnimeList(page, 24, {
      type: type || undefined,
      status: status || undefined,
      order_by: orderBy,
      sort: sort,
    }),
  });

  // Fetch genres for filter
  const { data: genresData } = useQuery({
    queryKey: ['anime-genres'],
    queryFn: () => genresApi.getAnimeGenres(),
  });

  const animeList = data?.data || [];
  const pagination = data?.pagination;
  const genres = genresData || [];

  const updateFilter = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
    setPage(1);
  };

  const clearFilters = () => {
    setSearchParams(new URLSearchParams());
    setPage(1);
  };

  const hasFilters = type || status || genre;

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <h1 className="text-2xl font-bold text-[var(--color-text)]">
          {t('nav.animeList')}
        </h1>

        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex bg-[var(--color-bg-secondary)] rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid'
                  ? 'bg-[#8b5cf6] text-white'
                  : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text)]'
              }`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list'
                  ? 'bg-[#8b5cf6] text-white'
                  : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text)]'
              }`}
            >
              <ListIcon className="w-4 h-4" />
            </button>
          </div>

          {/* Filter Button */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              showFilters || hasFilters
                ? 'bg-[#8b5cf6] text-white'
                : 'bg-[var(--color-bg-secondary)] text-[var(--color-text)]'
            }`}
          >
            <Filter className="w-4 h-4" />
            {t('filter.title')}
          </button>
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="bg-[var(--color-bg-secondary)] rounded-xl p-6 mb-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">{t('filter.title')}</h3>
            {hasFilters && (
              <button
                onClick={clearFilters}
                className="text-sm text-red-500 hover:underline"
              >
                {t('filter.clearAll')}
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Type Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                {t('filter.type')}
              </label>
              <select
                value={type}
                onChange={(e) => updateFilter('type', e.target.value)}
                className="w-full px-3 py-2 bg-[var(--color-bg-tertiary)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
              >
                <option value="">{t('common.all')}</option>
                <option value="tv">{t('types.tv')}</option>
                <option value="movie">{t('types.movie')}</option>
                <option value="ova">{t('types.ova')}</option>
                <option value="special">{t('types.special')}</option>
                <option value="ona">{t('types.ona')}</option>
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                {t('filter.status')}
              </label>
              <select
                value={status}
                onChange={(e) => updateFilter('status', e.target.value)}
                className="w-full px-3 py-2 bg-[var(--color-bg-tertiary)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
              >
                <option value="">{t('filter.status')}</option>
                <option value="airing">{t('statusFilter.airing')}</option>
                <option value="complete">{t('statusFilter.complete')}</option>
                <option value="upcoming">{t('statusFilter.upcoming')}</option>
              </select>
            </div>

            {/* Order By Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                {t('filter.orderBy')}
              </label>
              <select
                value={orderBy}
                onChange={(e) => updateFilter('order_by', e.target.value)}
                className="w-full px-3 py-2 bg-[var(--color-bg-tertiary)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
              >
                <option value="popularity">{t('anime.popularity')}</option>
                <option value="score">{t('anime.score')}</option>
                <option value="start_date">{t('anime.aired')}</option>
                <option value="episodes">{t('anime.totalEpisodes')}</option>
              </select>
            </div>

            {/* Sort Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                {t('filter.sort')}
              </label>
              <select
                value={sort}
                onChange={(e) => updateFilter('sort', e.target.value)}
                className="w-full px-3 py-2 bg-[var(--color-bg-tertiary)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
              >
                <option value="desc">{t('filter.descending')}</option>
                <option value="asc">{t('filter.ascending')}</option>
              </select>
            </div>
          </div>

          {/* Genre Filter */}
          <div className="mt-4">
            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
              {t('filter.genre')}
            </label>
            <div className="flex flex-wrap gap-2">
              {genres.map((genreItem: any) => (
                <button
                  key={genreItem.mal_id}
                  onClick={() => updateFilter('genre', genreItem.mal_id.toString())}
                  className={`filter-pill ${genre === genreItem.mal_id.toString() ? 'active' : ''}`}
                >
                  {genreItem.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Active Filters */}
      {hasFilters && (
        <div className="flex flex-wrap gap-2 mb-6">
          {type && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#8b5cf6]/20 text-[#8b5cf6] rounded-full text-sm">
              {type}
              <button onClick={() => updateFilter('type', '')}>
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          {status && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#06b6d4]/20 text-[#06b6d4] rounded-full text-sm">
              {status}
              <button onClick={() => updateFilter('status', '')}>
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          {genre && (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#f97316]/20 text-[#f97316] rounded-full text-sm">
              {genres.find((g: any) => g.mal_id.toString() === genre)?.name}
              <button onClick={() => updateFilter('genre', '')}>
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
        </div>
      )}

      {/* Anime Grid */}
      {isLoading ? (
        <Loading />
      ) : isError ? (
        <div className="text-center py-12 text-red-500">
          {t('errors.loadFailed')}
        </div>
      ) : (
        <>
          <div className={`anime-grid stagger-grid ${viewMode === 'list' ? 'grid-cols-1' : ''}`}>
            {animeList.map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>

          {/* Pagination */}
          {pagination && (
            <div className="flex items-center justify-center gap-2 mt-8">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <span className="px-4 py-2 text-[var(--color-text)]">
                {page} / {pagination.last_visible_page}
              </span>

              <button
                onClick={() => setPage(page + 1)}
                disabled={!pagination.has_next_page}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
