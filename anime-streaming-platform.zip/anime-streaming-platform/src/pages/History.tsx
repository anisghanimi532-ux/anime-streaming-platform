import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { History as HistoryIcon, Play, Trash2 } from 'lucide-react';
import { useHistoryStore } from '../lib/store';

export default function History() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { history, clearHistory } = useHistoryStore();

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <HistoryIcon className="w-8 h-8 text-[#f97316]" />
          <h1 className="text-2xl font-bold text-[var(--color-text)]">
            {t('nav.watchHistory')}
          </h1>
        </div>
        {history.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear your watch history?')) {
                clearHistory();
              }
            }}
            className="flex items-center gap-2 px-4 py-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
          >
            <Trash2 className="w-5 h-5" />
            Clear History
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="empty-state">
          <HistoryIcon className="empty-state-icon" />
          <h3 className="text-xl font-semibold text-[var(--color-text)] mb-2">
            {t('common.noResults')}
          </h3>
          <p className="text-[var(--color-text-secondary)] mb-4">
            Start watching anime to see your history here!
          </p>
          <Link to="/anime" className="btn-primary">
            Browse Anime
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((item) => (
            <Link
              key={item.id}
              to={`/anime/${item.anime.mal_id}/episode/${item.episode_number}`}
              className="flex items-center gap-4 p-4 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
            >
              <img
                src={item.anime.images?.jpg?.image_url}
                alt={item.anime.title}
                className="w-16 h-20 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-[var(--color-text)] line-clamp-1">
                  {item.anime.title_english || item.anime.title}
                </h3>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  {t('anime.episode')} {item.episode_number}
                </p>
                <p className="text-xs text-[var(--color-text-secondary)]">
                  {new Date(item.watched_at).toLocaleDateString()}
                </p>
              </div>
              <Play className="w-8 h-8 text-[#8b5cf6]" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
