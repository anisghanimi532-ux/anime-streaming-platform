import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  Search,
  Home as HomeIcon,
  Play,
  List,
  Film,
  TrendingUp,
  Star,
  Clock,
  ChevronRight,
  Filter,
} from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';

// API
import { animeApi, genresApi } from '../lib/jikanApi';

// Components
import AnimeCard from '../components/AnimeCard';

export default function Home() {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const [emblaRef] = useEmblaCarousel({ loop: true, align: 'start' });

  // Fetch data
  const { data: trendingData } = useQuery({
    queryKey: ['trending-anime'],
    queryFn: () => animeApi.getTopAnime('bypopularity', 1, 12),
  });

  const { data: topRatedData } = useQuery({
    queryKey: ['top-rated-anime'],
    queryFn: () => animeApi.getTopAnime('score', 1, 12),
  });

  const { data: latestData } = useQuery({
    queryKey: ['latest-anime'],
    queryFn: () => animeApi.getLatestAnime(1, 12),
  });

  const { data: moviesData } = useQuery({
    queryKey: ['anime-movies'],
    queryFn: () => animeApi.getAnimeMovies(1, 12),
  });

  const { data: genresData } = useQuery({
    queryKey: ['anime-genres'],
    queryFn: () => genresApi.getAnimeGenres(),
  });

  const trendingAnime = trendingData?.data || [];
  const topRatedAnime = topRatedData?.data || [];
  const latestAnime = latestData?.data || [];
  const moviesAnime = moviesData?.data || [];
  const genres = genresData || [];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-bg" />
        <div className="hero-glow animate-pulse-glow" />
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            <span className="gradient-text">{t('home.hero.title')}</span>
          </h1>
          <p className="text-lg md:text-xl text-[var(--color-text-secondary)] mb-8 max-w-2xl mx-auto">
            {t('home.hero.subtitle')}
          </p>

          {/* Main Navigation Pills */}
          <div className="flex flex-wrap justify-center gap-4 mb-10">
            <Link to="/" className="nav-pill-primary">
              <HomeIcon className="w-5 h-5" />
              {t('nav.home')}
            </Link>
            <Link to="/?status=airing" className="nav-pill-secondary">
              <Play className="w-5 h-5" />
              {t('nav.newEpisodes')}
            </Link>
            <Link to="/anime" className="nav-pill-tertiary">
              <List className="w-5 h-5" />
              {t('nav.animeList')}
            </Link>
            <Link to="/movies" className="nav-pill-quaternary">
              <Film className="w-5 h-5" />
              {t('nav.movies')}
            </Link>
          </div>

          {/* Search Bar */}
          <form action="/search" method="get" className="search-bar">
            <Search className="search-icon" />
            <input
              type="text"
              name="q"
              placeholder={t('nav.searchPlaceholder')}
              className="search-input"
            />
          </form>
        </div>
      </section>

      {/* Content */}
      <div className="container mx-auto px-4 py-10">
        {/* Genres Filter */}
        <section className="mb-10">
          <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2">
            <Filter className="w-5 h-5 text-[var(--color-text-secondary)]" />
            <h2 className="text-lg font-semibold text-[var(--color-text)] whitespace-nowrap">
              {t('filter.genre')}
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {genres.slice(0, 12).map((genre: any) => (
              <Link
                key={genre.mal_id}
                to={`/anime?genre=${genre.mal_id}`}
                className="genre-pill"
              >
                {genre.name}
              </Link>
            ))}
          </div>
        </section>

        {/* Trending Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-[#8b5cf6]" />
              <h2 className="text-2xl font-bold text-[var(--color-text)]">
                {t('home.sections.trendingNow')}
              </h2>
            </div>
            <Link
              to="/anime?order_by=popularity"
              className="flex items-center gap-1 text-[#8b5cf6] hover:text-[#7c3aed] transition-colors"
            >
              {t('common.seeMore')}
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="anime-grid stagger-grid">
            {trendingAnime.slice(0, 6).map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>
        </section>

        {/* Top Rated Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Star className="w-6 h-6 text-yellow-400" />
              <h2 className="text-2xl font-bold text-[var(--color-text)]">
                {t('home.sections.topRated')}
              </h2>
            </div>
            <Link
              to="/anime?order_by=score"
              className="flex items-center gap-1 text-[#8b5cf6] hover:text-[#7c3aed] transition-colors"
            >
              {t('common.seeMore')}
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="anime-grid stagger-grid">
            {topRatedAnime.slice(0, 6).map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>
        </section>

        {/* Latest Releases Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Clock className="w-6 h-6 text-[#06b6d4]" />
              <h2 className="text-2xl font-bold text-[var(--color-text)]">
                {t('home.sections.latestReleases')}
              </h2>
            </div>
            <Link
              to="/anime?order_by=start_date"
              className="flex items-center gap-1 text-[#8b5cf6] hover:text-[#7c3aed] transition-colors"
            >
              {t('common.seeMore')}
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="anime-grid stagger-grid">
            {latestAnime.slice(0, 6).map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>
        </section>

        {/* Movies Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Film className="w-6 h-6 text-[#f97316]" />
              <h2 className="text-2xl font-bold text-[var(--color-text)]">
                {t('nav.movies')}
              </h2>
            </div>
            <Link
              to="/movies"
              className="flex items-center gap-1 text-[#8b5cf6] hover:text-[#7c3aed] transition-colors"
            >
              {t('common.seeMore')}
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="anime-grid stagger-grid">
            {moviesAnime.slice(0, 6).map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="bg-[var(--color-bg-secondary)] py-8 mt-12">
        <div className="container mx-admin px-4 text-center">
          <p className="text-[var(--color-text-secondary)]">
            AnimeStream - Your Favorite Anime Streaming Platform
          </p>
          <p className="text-sm text-[var(--color-text-secondary)] mt-2">
            Data provided by MyAnimeList
          </p>
        </div>
      </footer>
    </div>
  );
}
