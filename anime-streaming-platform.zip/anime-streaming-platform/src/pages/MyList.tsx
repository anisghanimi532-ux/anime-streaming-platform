import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { List, Filter, SortAsc, SortDesc } from 'lucide-react';
import { useWatchlistStore } from '../lib/store';
import AnimeCard from '../components/AnimeCard';

export default function MyList() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { watchlist } = useWatchlistStore();
  const [filter, setFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'title'>('recent');

  const statusFilters = [
    { key: 'all', label: t('filter.status') },
    { key: 'watching', label: t('status.watching') },
    { key: 'completed', label: t('status.completed') },
    { key: 'on_hold', label: t('status.onHold') },
    { key: 'dropped', label: t('status.dropped') },
    { key: 'plan_to_watch', label: t('status.planToWatch') },
  ];

  const filteredList = watchlist
    .filter((item) => filter === 'all' || item.status === filter)
    .sort((a, b) => {
      if (sortBy === 'title') {
        return (a.anime.title_english || a.anime.title).localeCompare(
          b.anime.title_english || b.anime.title
        );
      }
      return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
    });

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex items-center gap-3 mb-6">
        <List className="w-8 h-8 text-[#06b6d4]" />
        <h1 className="text-2xl font-bold text-[var(--color-text)]">
          {t('nav.myList')}
        </h1>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-[var(--color-text-secondary)]" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-3 py-2 bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-lg text-[var(--color-text)]"
          >
            {statusFilters.map((f) => (
              <option key={f.key} value={f.key}>
                {f.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSortBy('recent')}
            className={`p-2 rounded-lg transition-colors ${
              sortBy === 'recent'
                ? 'bg-[#8b5cf6] text-white'
                : 'bg-[var(--color-bg-secondary)] text-[var(--color-text)]'
            }`}
          >
            <SortDesc className="w-5 h-5" />
          </button>
          <button
            onClick={() => setSortBy('title')}
            className={`p-2 rounded-lg transition-colors ${
              sortBy === 'title'
                ? 'bg-[#8b5cf6] text-white'
                : 'bg-[var(--color-bg-secondary)] text-[var(--color-text)]'
            }`}
          >
            <SortAsc className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* List */}
      {filteredList.length === 0 ? (
        <div className="empty-state">
          <List className="empty-state-icon" />
          <h3 className="text-xl font-semibold text-[var(--color-text)] mb-2">
            {t('common.noResults')}
          </h3>
          <p className="text-[var(--color-text-secondary)] mb-4">
            Start adding anime to your watchlist!
          </p>
          <Link to="/anime" className="btn-primary">
            Browse Anime
          </Link>
        </div>
      ) : (
        <div className="anime-grid">
          {filteredList.map((item) => (
            <div key={item.id} className="relative">
              <AnimeCard anime={item.anime} />
              <div className="absolute top-2 right-2 z-10">
                <span className={`px-2 py-1 text-xs font-semibold rounded-lg ${
                  item.status === 'watching' ? 'bg-[#22c55e] text-white' :
                  item.status === 'completed' ? 'bg-[#06b6d4] text-white' :
                  item.status === 'on_hold' ? 'bg-[#f59e0b] text-white' :
                  item.status === 'dropped' ? 'bg-[#ef4444] text-white' :
                  'bg-[#8b5cf6] text-white'
                }`}>
                  {t(`status.${item.status.replace('_', '')}`)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
