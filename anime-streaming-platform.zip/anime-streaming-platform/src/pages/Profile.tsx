import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import {
  User,
  Settings,
  Heart,
  List,
  History,
  LogOut,
  Camera,
} from 'lucide-react';
import { useAuthStore } from '../lib/store';
import { authApi } from '../lib/supabase';

export default function Profile() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { user, logout, isAuthenticated } = useAuthStore();

  if (!isAuthenticated || !user) {
    navigate('/login');
    return null;
  }

  const handleLogout = async () => {
    await authApi.signOut();
    logout();
    navigate('/');
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-[var(--color-bg-secondary)] rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center">
                <User className="w-12 h-12 text-white" />
              </div>
              <button className="absolute bottom-0 right-0 p-2 bg-[#8b5cf6] rounded-full text-white hover:bg-[#7c3aed]">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-[var(--color-text)]">
                {user.username || user.email}
              </h1>
              <p className="text-[var(--color-text-secondary)]">{user.email}</p>
            </div>
          </div>
        </div>

        {/* Menu */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link
            to="/my-list"
            className="flex items-center gap-4 p-4 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#22c55e] flex items-center justify-center">
              <List className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-[var(--color-text)]">{t('nav.myList')}</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">
                Manage your watchlist
              </p>
            </div>
          </Link>

          <Link
            to="/favorites"
            className="flex items-center gap-4 p-4 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#ec4899] flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-[var(--color-text)]">{t('nav.favorites')}</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">
                Your favorite anime
              </p>
            </div>
          </Link>

          <Link
            to="/history"
            className="flex items-center gap-4 p-4 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#f97316] to-[#f59e0b] flex items-center justify-center">
              <History className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-[var(--color-text)]">{t('nav.watchHistory')}</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">
                Continue watching
              </p>
            </div>
          </Link>

          <button
            onClick={handleLogout}
            className="flex items-center gap-4 p-4 bg-red-500/10 border border-red-500/20 rounded-xl hover:bg-red-500/20 transition-colors"
          >
            <div className="w-12 h-12 rounded-xl bg-red-500 flex items-center justify-center">
              <LogOut className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-red-500">{t('nav.logout')}</h3>
              <p className="text-sm text-[var(--color-text-secondary)]">
                Sign out of your account
              </p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
