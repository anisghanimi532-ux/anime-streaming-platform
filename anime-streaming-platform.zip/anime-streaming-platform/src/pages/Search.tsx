import { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { Search as SearchIcon, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { animeApi } from '../lib/jikanApi';
import AnimeCard from '../components/AnimeCard';
import Loading from '../components/Loading';

export default function Search() {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const queryParam = searchParams.get('q') || '';
  const type = searchParams.get('type') || '';

  const [searchInput, setSearchInput] = useState(queryParam);
  const [page, setPage] = useState(1);

  useEffect(() => {
    setSearchInput(queryParam);
  }, [queryParam]);

  const { data, isLoading, isError } = useQuery({
    queryKey: ['search-anime', queryParam, page],
    queryFn: () => animeApi.searchAnime(queryParam, page, 24),
    enabled: !!queryParam,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setSearchParams({ q: searchInput.trim() });
      setPage(1);
    }
  };

  const results = data?.data || [];
  const pagination = data?.pagination;

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-[var(--color-text)] mb-6">
        {t('nav.search')}
      </h1>

      {/* Search Form */}
      <form onSubmit={handleSearch} className="mb-8">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-[var(--color-text-secondary)]" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder={t('nav.searchPlaceholder')}
            className="w-full pl-12 pr-4 py-4 bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl text-[var(--color-text)] placeholder-[var(--color-text-secondary)] focus:outline-none focus:border-[#8b5cf6]"
          />
          {searchInput && (
            <button
              type="button"
              onClick={() => {
                setSearchInput('');
                setSearchParams({});
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--color-text-secondary)] hover:text-[var(--color-text)]"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </form>

      {/* Results */}
      {!queryParam ? (
        <div className="text-center py-12">
          <SearchIcon className="w-16 h-16 text-[var(--color-text-secondary)] mx-auto mb-4" />
          <p className="text-[var(--color-text-secondary)]">
            {t('common.noResults')}
          </p>
        </div>
      ) : isLoading ? (
        <Loading />
      ) : isError ? (
        <div className="text-center py-12 text-red-500">
          {t('errors.loadFailed')}
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-[var(--color-text-secondary)]">
            No results found for "{queryParam}"
          </p>
        </div>
      ) : (
        <>
          <p className="text-[var(--color-text-secondary)] mb-6">
            Found {pagination?.items?.total || 0} results for "{queryParam}"
          </p>

          <div className="anime-grid">
            {results.map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>

          {/* Pagination */}
          {pagination && (
            <div className="flex items-center justify-center gap-2 mt-8">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <span className="px-4 py-2 text-[var(--color-text)]">
                {page} / {pagination.last_visible_page}
              </span>
              <button
                onClick={() => setPage(page + 1)}
                disabled={!pagination.has_next_page}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
