import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { useFavoritesStore } from '../lib/store';
import AnimeCard from '../components/AnimeCard';

export default function Favorites() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { favorites } = useFavoritesStore();

  return (
  <div className="container mx-auto px-4 py-6">
    <div className="flex items-center gap-3 mb-6">
      <Heart className="w-8 h-8 text-red-500" />
      <h1 className="text-2xl font-bold text-[var(--color-text)]">
        {t('nav.favorites')}
      </h1>
    </div>

    {favorites.length === 0 ? (
      <div className="empty-state">
        <Heart className="empty-state-icon" />
        <h3 className="text-xl font-semibold text-[var(--color-text)] mb-2">
          {t('common.noResults')}
        </h3>
        <p className="text-[var(--color-text-secondary)] mb-4">
          Start adding anime to your favorites!
        </p>
        <Link to="/anime" className="btn-primary">
          Browse Anime
        </Link>
      </div>
    ) : (
      <div className="anime-grid">
        {favorites.map((item) => (
          <AnimeCard key={item.id} anime={item.anime} />
        ))}
      </div>
    )}
  </div>
  );
}
