import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  Film,
  ChevronLeft,
  ChevronRight,
  Grid,
  List as ListIcon,
} from 'lucide-react';

// API
import { animeApi } from '../lib/jikanApi';

// Components
import AnimeCard from '../components/AnimeCard';
import Loading from '../components/Loading';

export default function Movies() {
  const { t } = useTranslation();
  const [page, setPage] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const { data, isLoading, isError } = useQuery({
    queryKey: ['anime-movies', page],
    queryFn: () => animeApi.getAnimeMovies(page, 24),
  });

  const movies = data?.data || [];
  const pagination = data?.pagination;

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Film className="w-8 h-8 text-[#f97316]" />
        <h1 className="text-2xl font-bold text-[var(--color-text)]">
          {t('nav.movies')}
        </h1>
      </div>

      {/* View Mode Toggle */}
      <div className="flex justify-end mb-6">
        <div className="flex bg-[var(--color-bg-secondary)] rounded-lg p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'grid'
                ? 'bg-[#8b5cf6] text-white'
                : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text)]'
            }`}
          >
            <Grid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'list'
                ? 'bg-[#8b5cf6] text-white'
                : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text)]'
            }`}
          >
            <ListIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Movies Grid */}
      {isLoading ? (
        <Loading />
      ) : isError ? (
        <div className="text-center py-12 text-red-500">
          {t('errors.loadFailed')}
        </div>
      ) : (
        <>
          <div className={`anime-grid stagger-grid ${viewMode === 'list' ? 'grid-cols-1' : ''}`}>
            {movies.map((anime: any) => (
              <AnimeCard key={anime.mal_id} anime={anime} />
            ))}
          </div>

          {/* Pagination */}
          {pagination && (
            <div className="flex items-center justify-center gap-2 mt-8">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <span className="px-4 py-2 text-[var(--color-text)]">
                {page} / {pagination.last_visible_page}
              </span>

              <button
                onClick={() => setPage(page + 1)}
                disabled={!pagination.has_next_page}
                className="p-2 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
