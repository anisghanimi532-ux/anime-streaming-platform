import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-[#8b5cf6] mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-[var(--color-text)] mb-4">
          Page Not Found
        </h2>
        <p className="text-[var(--color-text-secondary)] mb-8">
          The page you are looking for does not exist.
        </p>
        <Link to="/" className="btn-primary flex items-center gap-2 mx-auto w-fit">
          <Home className="w-5 h-5" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
