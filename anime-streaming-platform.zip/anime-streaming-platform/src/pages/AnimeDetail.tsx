import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  Play,
  Heart,
  Plus,
  Star,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Clock,
  Film,
  Users,
  Award,
  TrendingUp,
  Share2,
  Check,
  Info,
} from 'lucide-react';

// API
import { animeApi, formatDate, getStatusLabel, getSourceLabel, getTypeLabel, getNextAirDate, calculateNextEpisodeDate } from '../lib/jikanApi';

// Store
import { useAuthStore, useFavoritesStore, useWatchlistStore, useRatingsStore } from '../lib/store';
import { favoritesApi, watchlistApi, ratingsApi } from '../lib/supabase';

// Components
import AnimeCard from '../components/AnimeCard';
import Loading from '../components/Loading';

export default function AnimeDetail() {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'episodes' | 'characters' | 'relations'>('overview');
  const [showAddToList, setShowAddToList] = useState(false);
  const [userRating, setUserRating] = useState(0);

  const { isAuthenticated, user } = useAuthStore();
  const { favorites, addFavorite, removeFavorite, isFavorite } = useFavoritesStore();
  const { watchlist: userWatchlist, addToWatchlist, updateWatchlist, removeFromWatchlist } = useWatchlistStore();
  const { ratings, setRating, getRating } = useRatingsStore();

  const animeId = parseInt(id || '0');

  // Fetch anime details
  const { data: anime, isLoading: isLoadingAnime, error } = useQuery({
    queryKey: ['anime', animeId],
    queryFn: () => animeApi.getAnimeById(animeId),
    enabled: !!animeId,
  });

  // Fetch recommendations
  const { data: recommendations } = useQuery({
    queryKey: ['anime-recommendations', animeId],
    queryFn: () => animeApi.getRecommendations(animeId),
    enabled: !!animeId,
  });

  // Fetch relations
  const { data: relations } = useQuery({
    queryKey: ['anime-relations', animeId],
    queryFn: () => animeApi.getRelations(animeId),
    enabled: !!animeId,
  });

  // Fetch episodes
  const { data: episodesData } = useQuery({
    queryKey: ['anime-episodes', animeId],
    queryFn: () => anime.type === 'Movie'
      ? animeApi.getAnimeEpisodesMovies(animeId)
      : animeApi.getAnimeEpisodes(animeId),
    enabled: !!animeId && selectedTab === 'episodes',
  });

  if (isLoadingAnime) return <Loading />;

  if (error || !anime) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold text-red-500">{t('errors.loadFailed')}</h2>
        <Link to="/" className="btn-primary mt-4">
          {t('nav.home')}
        </Link>
      </div>
    );
  }

  const animeData = anime.data;
  const isFav = isFavorite(animeId);
  const watchlistItem = userWatchlist.find(item => item.anime.mal_id === animeId);
  const userAnimeRating = getRating(animeId);

  const handleToggleFavorite = async () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (isFav) {
      removeFavorite(animeId);
      if (user) await favoritesApi.removeFavorite(user.id, animeId);
    } else {
      addFavorite({
        mal_id: animeData.mal_id,
        title: animeData.title,
        title_english: animeData.title_english,
        images: animeData.images,
        type: animeData.type,
        episodes: animeData.episodes,
        status: animeData.status,
        score: animeData.score,
        genres: animeData.genres,
      });
      if (user) await favoritesApi.addFavorite(user.id, animeId);
    }
  };

  const handleAddToList = async (status: 'watching' | 'completed' | 'dropped' | 'on_hold' | 'plan_to_watch') => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    addToWatchlist({
      mal_id: animeData.mal_id,
      title: animeData.title,
      title_english: animeData.title_english,
      images: animeData.images,
      type: animeData.type,
      episodes: animeData.episodes,
      status: animeData.status,
      score: animeData.score,
      genres: animeData.genres,
    }, status);

    if (user) await watchlistApi.addToWatchlist(user.id, animeData.mal_id, status);

    setShowAddToList(false);
  };

  const handleRemoveFromList = async () => {
    if (user) await watchlistApi.removeFromWatchlist(user.id, animeId);
    removeFromWatchlist(animeId);
  };

  const handleRate = async (score: number) => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    setRating(animeId, score);
    setUserRating(score);
    if (user) await ratingsApi.setRating(user.id, animeId, score);
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-[#22c55e]';
    if (score >= 7) return 'bg-[#06b6d4]';
    if (score >= 6) return 'bg-[#f59e0b]';
    if (score >= 5) return 'bg-[#f97316]';
    return 'bg-[#ef4444]';
  };

  const nextEpisode = calculateNextEpisodeDate(
    undefined,
    animeData.broadcast,
    animeData.episodes
  );

  return (
    <div className="min-h-screen">
      {/* Hero Background */}
      <div
        className="relative h-[500px] bg-cover bg-center"
        style={{
          backgroundImage: `url(${animeData.images.jpg.large_image_url})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-bg)] via-[var(--color-bg)]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-bg)]/90 to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 -mt-[400px] relative z-10">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <img
              src={animeData.images.jpg.large_image_url}
              alt={animeData.title_english || animeData.title}
              className="w-64 rounded-xl shadow-2xl mx-auto lg:mx-0"
            />
          </div>

          {/* Info */}
          <div className="flex-1">
            {/* Title */}
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              {animeData.title_english || animeData.title}
            </h1>
            {animeData.title_japanese && (
              <p className="text-lg text-[var(--color-text-secondary)] mb-4">
                {animeData.title_japanese}
              </p>
            )}

            {/* Score */}
            {animeData.score && (
              <div className="flex items-center gap-4 mb-4">
                <div className={`flex items-center gap-2 px-4 py-2 ${getScoreColor(animeData.score)} text-white rounded-lg`}>
                  <Star className="w-5 h-5 fill-current" />
                  <span className="text-xl font-bold">{animeData.score.toFixed(1)}</span>
                </div>
                <span className="text-[var(--color-text-secondary)]">
                  {animeData.scored_by?.toLocaleString()} {t('rating.scored_by')}
                </span>
              </div>
            )}

            {/* Quick Actions */}
            <div className="flex flex-wrap gap-3 mb-6">
              <Link
                to={`/anime/${animeId}/episode/1`}
                className="btn-primary flex items-center gap-2"
              >
                <Play className="w-5 h-5" />
                {t('anime.episodes')}
              </Link>
              <button
                onClick={handleToggleFavorite}
                className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                  isFav
                    ? 'bg-red-500 text-white'
                    : 'bg-[var(--color-bg-tertiary)] text-[var(--color-text)] hover:bg-red-500 hover:text-white'
                }`}
              >
                <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
                {isFav ? t('anime.removeFromFavorites') : t('anime.addToFavorites')}
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowAddToList(!showAddToList)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                    watchlistItem
                      ? 'bg-[#8b5cf6] text-white'
                      : 'bg-[var(--color-bg-tertiary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white'
                  }`}
                >
                  <Plus className="w-5 h-5" />
                  {watchlistItem ? t(`status.${watchlistItem.status.replace('_', '')}`) : t('anime.addToList')}
                </button>
                {showAddToList && (
                  <div className="absolute top-full left-0 mt-2 w-48 bg-[var(--color-card)] border border-[var(--color-border)] rounded-xl shadow-xl z-10">
                    {['watching', 'completed', 'on_hold', 'dropped', 'plan_to_watch'].map((status) => (
                      <button
                        key={status}
                        onClick={() => handleAddToList(status as any)}
                        className="w-full px-4 py-3 text-left hover:bg-[var(--color-bg-secondary)] transition-colors first:rounded-t-xl last:rounded-b-xl"
                      >
                        {t(`status.${status.replace('_', '')}`)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Next Episode */}
            {animeData.airing && nextEpisode && (
              <div className="bg-[#22c55e]/20 border border-[#22c55e] rounded-xl p-4 mb-6">
                <div className="flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-[#22c55e]" />
                  <div>
                    <p className="text-sm text-[#22c55e] font-medium">{t('anime.nextEpisode')}</p>
                    <p className="text-white font-semibold">{nextEpisode.formatted}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Tabs */}
            <div className="flex gap-2 mb-6 overflow-x-auto border-b border-[var(--color-border)]">
              {['overview', 'episodes', 'relations'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setSelectedTab(tab as typeof selectedTab)}
                  className={`px-4 py-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
                    selectedTab === tab
                      ? 'border-[#8b5cf6] text-[#8b5cf6]'
                      : 'border-transparent text-[var(--color-text-secondary)] hover:text-[var(--color-text)]'
                  }`}
                >
                  {t(`anime.${tab === 'overview' ? 'information' : tab}`)}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            {selectedTab === 'overview' && (
              <div className="space-y-6">
                {/* Synopsis */}
                {animeData.synopsis && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2">{t('anime.overview')}</h3>
                    <p className="text-[var(--color-text-secondary)] leading-relaxed">
                      {animeData.synopsis}
                    </p>
                  </div>
                )}

                {/* Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {animeData.type && (
                    <InfoItem icon={Film} label={t('anime.type')} value={getTypeLabel(animeData.type)} />
                  )}
                  {animeData.status && (
                    <InfoItem
                      icon={Info}
                      label={t('anime.status')}
                      value={getStatusLabel(animeData.status, animeData.airing)}
                    />
                  )}
                  {animeData.episodes && (
                    <InfoItem
                      icon={Play}
                      label={t('anime.totalEpisodes')}
                      value={`${animeData.episodes} ${t('anime.episodes')}`}
                    />
                  )}
                  {animeData.aired?.string && (
                    <InfoItem icon={Calendar} label={t('anime.aired')} value={animeData.aired.string} />
                  )}
                  {animeData.duration && (
                    <InfoItem icon={Clock} label={t('anime.duration')} value={animeData.duration} />
                  )}
                  {animeData.source && (
                    <InfoItem icon={Info} label={t('anime.sources')} value={getSourceLabel(animeData.source)} />
                  )}
                  {animeData.score && (
                    <InfoItem icon={Star} label={t('anime.score')} value={animeData.score.toFixed(1)} />
                  )}
                  {animeData.rank && (
                    <InfoItem icon={Award} label={t('anime.rank')} value={`#${animeData.rank}`} />
                  )}
                  {animeData.popularity && (
                    <InfoItem icon={TrendingUp} label={t('anime.popularity')} value={`#${animeData.popularity}`} />
                  )}
                  {animeData.members && (
                    <InfoItem icon={Users} label={t('anime.members')} value={animeData.members.toLocaleString()} />
                  )}
                </div>

                {/* Studios */}
                {animeData.studios && animeData.studios.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                      {t('anime.studios')}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {animeData.studios.map((studio) => (
                        <span key={studio.mal_id} className="badge-primary">
                          {studio.name}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Genres */}
                {animeData.genres && animeData.genres.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                      {t('anime.genres')}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {animeData.genres.map((genre) => (
                        <Link
                          key={genre.mal_id}
                          to={`/anime?genre=${genre.mal_id}`}
                          className="genre-pill"
                        >
                          {genre.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {/* User Rating */}
                <div className="bg-[var(--color-bg-secondary)] rounded-xl p-4">
                  <h4 className="text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                    {t('rating.yourRating')}
                  </h4>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
                      <button
                        key={score}
                        onClick={() => handleRate(score)}
                        className={`w-8 h-8 rounded-lg font-semibold transition-colors ${
                          (userRating || userAnimeRating) === score
                            ? 'bg-[#f59e0b] text-white'
                            : 'bg-[var(--color-bg-tertiary)] text-[var(--color-text)] hover:bg-[#8b5cf6] hover:text-white'
                        }`}
                      >
                        {score}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {selectedTab === 'episodes' && (
              <div className="space-y-2">
                {episodesData?.data?.length > 0 ? (
                  episodesData.data.map((episode: any, index: number) => (
                    <Link
                      key={episode.mal_id}
                      to={`/anime/${animeId}/episode/${episode.episode}`}
                      className="flex items-center gap-4 p-4 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
                    >
                      <span className="w-12 h-12 flex items-center justify-center bg-[#8b5cf6] rounded-lg text-white font-bold">
                        {episode.episode}
                      </span>
                      <div className="flex-1">
                        <p className="font-medium text-[var(--color-text)] line-clamp-1">
                          {episode.title || `${t('anime.episode')} ${episode.episode}`}
                        </p>
                        {episode.aired && (
                          <p className="text-sm text-[var(--color-text-secondary)]">
                            {formatDate(episode.aired)}
                          </p>
                        )}
                      </div>
                      {episode.filler && (
                        <span className="px-2 py-1 bg-[#f97316]/20 text-[#f97316] text-xs rounded">
                          Filler
                        </span>
                      )}
                    </Link>
                  ))
                ) : (
                  <p className="text-center text-[var(--color-text-secondary)] py-8">
                    {t('common.noResults')}
                  </p>
                )}
              </div>
            )}

            {selectedTab === 'relations' && relations && relations.length > 0 && (
              <div className="space-y-4">
                {relations.map((relation: any) => (
                  <div key={relation.relation}>
                    <h4 className="text-sm font-medium text-[var(--color-text-secondary)] mb-2">
                      {relation.relation}
                    </h4>
                    <div className="flex flex-wrap gap-4">
                      {relation.entry.map((item: any) => (
                        <Link
                          key={item.mal_id}
                          to={item.type === 'anime' ? `/anime/${item.mal_id}` : `/manga/${item.mal_id}`}
                          className="flex items-center gap-3 p-3 bg-[var(--color-bg-secondary)] rounded-xl hover:bg-[var(--color-bg-tertiary)] transition-colors"
                        >
                          <span className="text-xs text-[var(--color-text-secondary)] uppercase">
                            {item.type}
                          </span>
                          <span className="text-[var(--color-text)]">{item.name}</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recommendations */}
        {recommendations && recommendations.length > 0 && (
          <section className="mt-12">
            <h2 className="text-2xl font-bold text-[var(--color-text)] mb-6">
              {t('nav.recommendations')}
            </h2>
            <div className="anime-grid">
              {recommendations.slice(0, 12).map((rec: any) => (
                <AnimeCard key={rec.mal_id} anime={rec.entry?.[0] || rec} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function InfoItem({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 p-3 bg-[var(--color-bg-secondary)] rounded-lg">
      <Icon className="w-5 h-5 text-[#8b5cf6]" />
      <div>
        <p className="text-xs text-[var(--color-text-secondary)]">{label}</p>
        <p className="text-sm font-medium text-[var(--color-text)]">{value}</p>
      </div>
    </div>
  );
}
