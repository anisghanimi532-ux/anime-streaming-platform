// src/lib/api.ts
import type { Anime, Episode } from '../types/anime';

const JIKAN_BASE_URL = 'https://api.jikan.moe/v4';

// Helper function for API calls
async function fetchAPI<T>(endpoint: string): Promise<T> {
  const response = await fetch(`${JIKAN_BASE_URL}${endpoint}`);
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  const data = await response.json();
  return data.data as T;
}

// Get top anime (for home page)
export async function getTopAnime(limit = 20): Promise<Anime[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/top/anime?limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get trending anime
export async function getTrendingAnime(limit = 20): Promise<Anime[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/top/anime?filter=bypopularity&limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get latest anime (seasonal)
export async function getLatestAnime(limit = 20): Promise<Anime[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/seasons/now?limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get upcoming anime
export async function getUpcomingAnime(limit = 20): Promise<Anime[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/seasons/upcoming?limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get anime movies
export async function getAnimeMovies(limit = 20): Promise<Anime[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/top/anime?type=movie&limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get anime by ID
export async function getAnimeById(id: number): Promise<Anime> {
  return fetchAPI(`/anime/${id}/full`);
}

// Get anime episodes
export async function getAnimeEpisodes(animeId: number, page = 1): Promise<Episode[]> {
  const response = await fetch(`${JIKAN_BASE_URL}/anime/${animeId}/episodes?page=${page}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get anime characters
export async function getAnimeCharacters(animeId: number) {
  const response = await fetch(`${JIKAN_BASE_URL}/anime/${animeId}/characters`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Search anime
export async function searchAnime(
  query: string,
  page = 1,
  limit = 25,
  filters?: {
    type?: string;
    status?: string;
    rating?: string;
    order_by?: string;
    sort?: string;
  }
): Promise<{ anime: Anime[]; pagination: any }> {
  const params = new URLSearchParams({
    q: query,
    page: page.toString(),
    limit: limit.toString(),
    ...filters,
  });

  const response = await fetch(`${JIKAN_BASE_URL}/anime?${params}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return {
    anime: data.data,
    pagination: data.pagination,
  };
}

// Get anime by genre
export async function getAnimeByGenre(genreId: number, page = 1, limit = 25): Promise<{ anime: Anime[]; pagination: any }> {
  const response = await fetch(`${JIKAN_BASE_URL}/anime?genres=${genreId}&page=${page}&limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return {
    anime: data.data,
    pagination: data.pagination,
  };
}

// Get anime by studio
export async function getAnimeByStudio(studioId: number, page = 1, limit = 25): Promise<{ anime: Anime[]; pagination: any }> {
  const response = await fetch(`${JIKAN_BASE_URL}/anime?studios=${studioId}&page=${page}&limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return {
    anime: data.data,
    pagination: data.pagination,
  };
}

// Get genres
export async function getGenres() {
  const response = await fetch(`${JIKAN_BASE_URL}/genres/anime`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get seasons
export async function getSeasons() {
  const response = await fetch(`${JIKAN_BASE_URL}/seasons`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get random anime
export async function getRandomAnime(): Promise<Anime> {
  return fetchAPI('/random/anime');
}

// Get recommendations
export async function getRecommendations(animeId: number): Promise<Anime[]> {
  return fetchAPI(`/anime/${animeId}/recommendations`);
}

// Get reviews
export async function getReviews(animeId: number, page = 1) {
  const response = await fetch(`${JIKAN_BASE_URL}/anime/${animeId}/reviews?page=${page}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}

// Get full anime list with filters
export async function getAnimeList(
  page = 1,
  limit = 25,
  filters?: {
    type?: string;
    status?: string;
    rating?: string;
    order_by?: string;
    sort?: string;
    start_date?: string;
    end_date?: string;
    genres?: string;
    studios?: string;
  }
): Promise<{ anime: Anime[]; pagination: any }> {
  const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...Object.fromEntries(
      Object.entries(filters || {}).filter(([_, v]) => v !== undefined && v !== '')
    ),
  });

  const response = await fetch(`${JIKAN_BASE_URL}/anime?${params}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return {
    anime: data.data,
    pagination: data.pagination,
  };
}

// Get schedules (airing today)
export async function getSchedules(day?: string) {
  const endpoint = day ? `/schedules?filter=${day}` : '/schedules';
  const response = await fetch(`${JIKAN_BASE_URL}${endpoint}`);
  if (!response.ok) throw new Error('Failed to fetch');
  const data = await response.json();
  return data.data;
}