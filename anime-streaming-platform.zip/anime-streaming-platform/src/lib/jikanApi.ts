// Jikan API (MyAnimeList unofficial API)
const JIKAN_API_BASE = 'https://api.jikan.moe/v4';

// Helper function to handle API requests with retry
async function fetchWithRetry(url: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url);
      if (response.status === 429) {
        // Rate limited, wait and retry
        await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
        continue;
      }
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      if (i === retries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
    }
  }
}

export interface Anime {
  mal_id: number;
  title: string;
  title_english?: string;
  title_japanese?: string;
  images: {
    jpg: {
      image_url: string;
      large_image_url: string;
      maximum_image_url?: string;
    };
    webp?: {
      image_url: string;
      large_image_url?: string;
    };
  };
  synopsis?: string;
  type: string;
  source?: string;
  episodes?: number;
  status: string;
  airing: boolean;
  aired: {
    from?: string;
    to?: string;
    string: string;
  };
  duration?: string;
  rating?: string;
  score?: number;
  scored_by?: number;
  rank?: number;
  popularity?: number;
  members?: number;
  favorites?: number;
  studios: { mal_id: number; name: string; type: string }[];
  genres: { mal_id: number; name: string; type: string }[];
  themes?: { mal_id: number; name: string; type: string }[];
  demographics?: { mal_id: number; name: string; type: string }[];
  producers?: { mal_id: number; name: string; type: string }[];
  licensors?: { mal_id: number; name: string; type: string }[];
  season?: string;
  year?: number;
  broadcast?: {
    day?: string;
    time?: string;
    timezone?: string;
    string?: string;
  };
  trailer?: {
    youtube_id?: string;
    url?: string;
    images?: {
      image_url?: string;
      small_image_url?: string;
      medium_image_url?: string;
      large_image_url?: string;
      maximum_image_url?: string;
    };
  };
  relations?: {
    relation: string;
    entry: {
      mal_id: number;
      type: string;
      name: string;
      url?: string;
    }[];
  }[];
  streaming?: {
    name: string;
    url: string;
  }[];
}

export interface EpisodeInfo {
  mal_id: number;
  anime_id: number;
  episode: number;
  title?: string;
  title_japanese?: string;
  title_romanji?: string;
  aired?: string;
  filler: boolean;
  recap: boolean;
  forum_url?: string;
  summary?: string;
}

export interface PaginationInfo {
  last_visible_page: number;
  has_next_page: boolean;
  current_page: number;
  items: {
    count: number;
    total: number;
    per_page: number;
  };
}

export interface ApiResponse<T> {
  data: T;
  pagination: PaginationInfo;
}

// Anime API
export const animeApi = {
  // Get top anime
  async getTopAnime(type = 'bypopularity', page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/top/anime?type=${type}&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get new episodes (currently airing with recent episodes)
  async getNewEpisodes() {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/watch/episodes`
    );
    return response as ApiResponse<any[]>;
  },

  // Get anime movies
  async getAnimeMovies(page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime?type=movie&order_by=score&sort=desc&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get latest anime (recently added)
  async getLatestAnime(page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime?order_by=start_date&sort=desc&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get trending anime
  async getTrendingAnime(page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime?order_by=popularity&sort=asc&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get upcoming anime
  async getUpcomingAnime(page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime?status=upcoming&order_by=popularity&sort=asc&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get anime by ID
  async getAnimeById(id: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${id}/full`
    );
    return response;
  },

  // Get anime episodes
  async getAnimeEpisodes(id: number, page = 1) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${id}/episodes?page=${page}`
    );
    return response as ApiResponse<EpisodeInfo[]>;
  },

  // Get anime episodes movies
  async getAnimeEpisodesMovies(id: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${id}/episodes`
    );
    return response as ApiResponse<EpisodeInfo[]>;
  },

  // Search anime
  async searchAnime(query: string, page = 1, limit = 25, filters?: {
    type?: string;
    status?: string;
    genre?: string;
    order_by?: string;
    sort?: string;
  }) {
    let url = `${JIKAN_API_BASE}/anime?q=${encodeURIComponent(query)}&page=${page}&limit=${limit}`;

    if (filters) {
      if (filters.type) url += `&type=${filters.type}`;
      if (filters.status) url += `&status=${filters.status}`;
      if (filters.genre) url += `&genres=${filters.genre}`;
      if (filters.order_by) url += `&order_by=${filters.order_by}`;
      if (filters.sort) url += `&sort=${filters.sort}`;
    }

    const response = await fetchWithRetry(url);
    return response as ApiResponse<Anime[]>;
  },

  // Get anime by genre
  async getAnimeByGenre(genre: number, string = 'desc', page = 1, limit = 25) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime?genres=${genre}&order_by=score&sort=${string}&page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get anime recommendations
  async getRecommendations(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/recommendations`
    );
    return response.data || [];
  },

  // Get anime relations
  async getRelations(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/relations`
    );
    return response.data || [];
  },

  // Get anime characters
  async getCharacters(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/characters`
    );
    return response.data || [];
  },

  // Get random anime
  async getRandomAnime() {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/random/anime`
    );
    return response.data;
  },

  // Get seasonal anime
  async getSeasonalAnime(year?: number, season?: string, page = 1, limit = 25) {
    const currentDate = new Date();
    const currentYear = year || currentDate.getFullYear();
    const seasons = ['winter', 'spring', 'summer', 'fall'];
    const currentSeasonIndex = Math.floor(currentDate.getMonth() / 3);
    const currentSeason = season || seasons[currentSeasonIndex];

    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/seasons/${currentYear}/${currentSeason}?page=${page}&limit=${limit}`
    );
    return response as ApiResponse<Anime[]>;
  },

  // Get full anime list
  async getFullAnimeList(page = 1, limit = 25, filters?: {
    type?: string;
    status?: string;
    order_by?: string;
    sort?: string;
  }) {
    let url = `${JIKAN_API_BASE}/anime?page=${page}&limit=${limit}`;

    if (filters) {
      if (filters.type) url += `&type=${filters.type}`;
      if (filters.status) url += `&status=${filters.status}`;
      if (filters.order_by) url += `&order_by=${filters.order_by}`;
      if (filters.sort) url += `&sort=${filters.sort}`;
    }

    const response = await fetchWithRetry(url);
    return response as ApiResponse<Anime[]>;
  },

  // Get anime news
  async getAnimeNews(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/news`
    );
    return response;
  },

  // Get anime statistics
  async getAnimeStatistics(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/statistics`
    );
    return response.data;
  },

  // Get anime-more info
  async getAnimeMoreInfo(animeId: number) {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/anime/${animeId}/moreinfo`
    );
    return response.data;
  }
};

// Genres API
export const genresApi = {
  async getAnimeGenres() {
    const response = await fetchWithRetry(
      `${JIKAN_API_BASE}/genres/anime`
    );
    return response.data || [];
  }
};

// Server mapping for anime episodes (open servers)
// Note: These are placeholder servers. In production, you'd use a proper video source API.
export const videoServers = [
  { name: 'gogoanime', label: 'GogoAnime', icon: '▶' },
  { name: 'zoro', label: 'Zoro', icon: '▶' },
  { name: 'upload', label: 'UploadVip', icon: '▶' },
  { name: 'streamtape', label: 'StreamTape', icon: '▶' },
];

// Get video URL from server (placeholder logic)
export const getVideoUrl = async (server: string, episodeId: string): Promise<string> => {
  // This is a placeholder. In a real implementation, you'd use an API like
  // enhancr.tv, animeapi.com, or your own backend to get actual video URLs

  // For demo purposes, return a placeholder video
  // In production, this would make an API call to get the actual video URL
  const placeholderVideos = [
    'https://example.com/video1.mp4',
    'https://example.com/video2.mp4',
  ];

  return placeholderVideos[Math.floor(Math.random() * placeholderVideos.length)];
};

// Utility functions
export const formatDate = (dateString?: string) => {
  if (!dateString) return 'Unknown';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

export const formatDuration = (duration?: string) => {
  if (!duration) return 'Unknown';
  return duration;
};

export const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case 'currently airing':
      return 'text-green-500';
    case 'finished airing':
      return 'text-blue-500';
    case 'not yet aired':
      return 'text-yellow-500';
    default:
      return 'text-gray-500';
  }
};

export const getStatusLabel = (status: string, airing: boolean) => {
  if (airing) return 'airing';
  if (status === 'Finished Airing') return 'completed';
  if (status === 'Not Yet Aired') return 'upcoming';
  return 'unknown';
};

export const getNextAirDate = (broadcast?: { day?: string; time?: string; string?: string }) => {
  if (!broadcast?.day) return null;

  const days: { [key: string]: number } = {
    'Sundays': 0, 'Mondays': 1, 'Tuesdays': 2, 'Wednesdays': 3,
    'Thursdays': 4, 'Fridays': 5, 'Saturdays': 6
  };

  const dayIndex = days[broadcast.day] ?? -1;
  if (dayIndex === -1) return null;

  const today = new Date();
  const dayDiff = (dayIndex - today.getDay() + 7) % 7 || 7;
  const nextDate = new Date(today);
  nextDate.setDate(today.getDate() + dayDiff);

  return {
    date: nextDate,
    time: broadcast.time || '',
    formatted: nextDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
  };
};

export const getSourceLabel = (source?: string) => {
  const labels: { [key: string]: string } = {
    'manga': 'Manga',
    'light_novel': 'Light Novel',
    'visual_novel': 'Visual Novel',
    'novel': 'Novel',
    'web_novel': 'Web Novel',
    'original': 'Original',
    '4_koma_manga': '4-Koma Manga',
    'web_manga': 'Web Manga',
    'card_game': 'Card Game',
    'mixed_media': 'Mixed Media',
    'game': 'Game',
    'music': 'Music',
    'picture_book': 'Picture Book',
    'radio': 'Radio',
    'other': 'Other',
  };
  return labels[source || ''] || source || 'Unknown';
};

export const getTypeLabel = (type: string) => {
  const labels: { [key: string]: string } = {
    'tv': 'TV',
    'movie': 'Movie',
    'ova': 'OVA',
    'special': 'Special',
    'ona': 'ONA',
    'music': 'Music',
  };
  return labels[type.toLowerCase()] || type;
};

// Calculate next episode date based on broadcast info and episode schedule
export const calculateNextEpisodeDate = (
  lastEpisodeDate?: string,
  broadcast?: { day?: string; time?: string },
  episodesAired?: number
) => {
  if (!broadcast?.day) return null;

  const days: { [key: string]: number } = {
    'Sundays': 0, 'Mondays': 1, 'Tuesdays': 2, 'Wednesdays': 3,
    'Thursdays': 4, 'Fridays': 5, 'Saturdays': 6
  };

  const dayIndex = days[broadcast.day] ?? -1;
  if (dayIndex === -1) return null;

  const today = new Date();
  const dayDiff = (dayIndex - today.getDay() + 7) % 7;
  const nextDate = new Date(today);
  nextDate.setDate(today.getDate() + (dayDiff || 7)); // If same day, show next week's date

  return {
    date: nextDate,
    time: broadcast.time || '',
    episode: (episodesAired || 0) + 1,
    formatted: nextDate.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    })
  };
};
