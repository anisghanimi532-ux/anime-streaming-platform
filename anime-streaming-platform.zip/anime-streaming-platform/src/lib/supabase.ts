import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://nqfhnrohgubqvwvopfrg.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5xZmhucm9oZ3VicXZ3dm9wZnJnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAwMDk1NTYsImV4cCI6MjA5NTU4NTU1Nn0.Ppa9E2ALaJJRF4HH70mkuOQo34Rng4YeRZBX46WwOZc';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface User {
  id: string;
  email: string;
  username: string;
  avatar_url?: string;
  created_at: string;
}

export interface Anime {
  id: number;
  title: string;
  title_english?: string;
  title_arabic?: string;
  images: { jpg: { image_url: string; large_image_url: string } };
  synopsis?: string;
  type: string;
  source?: string;
  episodes?: number;
  status: string;
  airing: boolean;
  aired: { string: string; to?: string };
  duration?: string;
  rating?: string;
  score?: number;
  scored_by?: number;
  rank?: number;
  popularity?: number;
  members?: number;
  favorites?: number;
  studios: { name: string }[];
  genres: { name: string }[];
  producers?: { name: string }[];
  licensors?: { name: string }[];
  season?: string;
  year?: number;
  broadcast?: string;
  next_air_date?: string;
  next_air_time?: string;
  next_air_day?: string;
}

export interface Episode {
  id: string;
  anime_id: number;
  episode_number: number;
  title: string;
  title_japanese?: string;
  aired: string;
  filler: boolean;
  recap: boolean;
  video_url?: string;
  forum_url?: string;
}

export interface Favorite {
  id: string;
  user_id: string;
  anime_id: number;
  created_at: string;
}

export interface Watchlist {
  id: string;
  user_id: string;
  anime_id: number;
  status: 'watching' | 'completed' | 'dropped' | 'on_hold' | 'plan_to_watch';
  progress?: number;
  score?: number;
  created_at: string;
  updated_at: string;
}

export interface WatchHistory {
  id: string;
  user_id: string;
  anime_id: number;
  episode_number: number;
  watched_at: string;
  progress: number;
}

export interface Comment {
  id: string;
  user_id: string;
  anime_id: number;
  episode_number?: number;
  content: string;
  created_at: string;
  updated_at?: string;
}

export interface UserRating {
  id: string;
  user_id: string;
  anime_id: number;
  score: number;
  created_at: string;
  updated_at: string;
}

// API functions
export const authApi = {
  async signUp(email: string, password: string, username: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { username } }
    });
    return { data, error };
  },

  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    return { data, error };
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  async getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  }
};

export const favoritesApi = {
  async getFavorites(userId: string) {
    const { data, error } = await supabase
      .from('favorites')
      .select('*')
      .eq('user_id', userId);
    return { data, error };
  },

  async addFavorite(userId: string, animeId: number) {
    const { data, error } = await supabase
      .from('favorites')
      .insert({ user_id: userId, anime_id: animeId });
    return { data, error };
  },

  async removeFavorite(userId: string, animeId: number) {
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('user_id', userId)
      .eq('anime_id', animeId);
    return { error };
  },

  async isFavorite(userId: string, animeId: number) {
    const { data, error } = await supabase
      .from('favorites')
      .select('id')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .single();
    return { data, error };
  }
};

export const watchlistApi = {
  async getWatchlist(userId: string) {
    const { data, error } = await supabase
      .from('watchlist')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });
    return { data, error };
  },

  async addToWatchlist(userId: string, animeId: number, status: string, progress = 0) {
    const { data, error } = await supabase
      .from('watchlist')
      .insert({
        user_id: userId,
        anime_id: animeId,
        status,
        progress
      })
      .select()
      .single();
    return { data, error };
  },

  async updateWatchlist(id: string, updates: Partial<Watchlist>) {
    const { data, error } = await supabase
      .from('watchlist')
      .update(updates)
      .eq('id', id);
    return { data, error };
  },

  async removeFromWatchlist(userId: string, animeId: number) {
    const { error } = await supabase
      .from('watchlist')
      .delete()
      .eq('user_id', userId)
      .eq('anime_id', animeId);
    return { error };
  },

  async getWatchlistItem(userId: string, animeId: number) {
    const { data, error } = await supabase
      .from('watchlist')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .single();
    return { data, error };
  }
};

export const historyApi = {
  async getHistory(userId: string) {
    const { data, error } = await supabase
      .from('watch_history')
      .select('*')
      .eq('user_id', userId)
      .order('watched_at', { ascending: false });
    return { data, error };
  },

  async addToHistory(userId: string, animeId: number, episodeNumber: number, progress: number) {
    // Check if entry exists
    const { data: existing } = await supabase
      .from('watch_history')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .eq('episode_number', episodeNumber)
      .single();

    if (existing) {
      const { data, error } = await supabase
        .from('watch_history')
        .update({ watched_at: new Date().toISOString(), progress })
        .eq('id', existing.id);
      return { data, error };
    }

    const { data, error } = await supabase
      .from('watch_history')
      .insert({
        user_id: userId,
        anime_id: animeId,
        episode_number: episodeNumber,
        progress
      });
    return { data, error };
  },

  async getLastWatchedEpisode(userId: string, animeId: number) {
    const { data, error } = await supabase
      .from('watch_history')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .order('episode_number', { ascending: false })
      .limit(1)
      .single();
    return { data, error };
  }
};

export const commentsApi = {
  async getComments(animeId: number, episodeNumber?: number) {
    let query = supabase
      .from('comments')
      .select(`
        *,
        user:profiles(username, avatar_url)
      `)
      .eq('anime_id', animeId)
      .order('created_at', { ascending: false });

    if (episodeNumber !== undefined) {
      query = query.eq('episode_number', episodeNumber);
    }

    const { data, error } = await query;
    return { data, error };
  },

  async addComment(userId: string, animeId: number, content: string, episodeNumber?: number) {
    const { data, error } = await supabase
      .from('comments')
      .insert({
        user_id: userId,
        anime_id: animeId,
        content,
        episode_number: episodeNumber
      });
    return { data, error };
  },

  async deleteComment(commentId: string, userId: string) {
    const { error } = await supabase
      .from('comments')
      .delete()
      .eq('id', commentId)
      .eq('user_id', userId);
    return { error };
  }
};

export const ratingsApi = {
  async getRating(userId: string, animeId: number) {
    const { data, error } = await supabase
      .from('user_ratings')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .single();
    return { data, error };
  },

  async setRating(userId: string, animeId: number, score: number) {
    const { data: existing } = await supabase
      .from('user_ratings')
      .select('id')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .single();

    if (existing) {
      const { data, error } = await supabase
        .from('user_ratings')
        .update({ score, updated_at: new Date().toISOString() })
        .eq('id', existing.id);
      return { data, error };
    }

    const { data, error } = await supabase
      .from('user_ratings')
      .insert({ user_id: userId, anime_id: animeId, score });
    return { data, error };
  }
};

export const profileApi = {
  async getProfile(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    return { data, error };
  },

  async updateProfile(userId: string, updates: { username?: string; avatar_url?: string }) {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId);
    return { data, error };
  }
};
