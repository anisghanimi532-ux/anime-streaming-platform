import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Types
export interface User {
  id: string;
  email: string;
  username: string;
  avatar_url?: string;
  created_at: string;
}

export interface AnimeInfo {
  mal_id: number;
  title: string;
  title_english?: string;
  images: {
    jpg: { image_url: string; large_image_url: string };
    webp?: { image_url: string; large_image_url?: string };
  };
  type: string;
  episodes?: number;
  status: string;
  score?: number;
  genres?: { name: string }[];
}

export interface WatchlistItem {
  id: string;
  anime: AnimeInfo;
  status: 'watching' | 'completed' | 'dropped' | 'on_hold' | 'plan_to_watch';
  progress: number;
  score?: number;
  created_at: string;
  updated_at: string;
}

export interface FavoriteItem {
  id: string;
  anime: AnimeInfo;
  created_at: string;
}

export interface HistoryItem {
  id: string;
  anime: AnimeInfo;
  episode_number: number;
  progress: number;
  watched_at: string;
}

// Auth Store
interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: true,
      isAuthenticated: false,
      setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
      setLoading: (isLoading) => set({ isLoading }),
      logout: () => set({ user: null, isAuthenticated: false }),
    }),
    {
      name: 'auth-storage',
    }
  )
);

// Theme Store
interface ThemeState {
  theme: 'light' | 'dark' | 'system';
  language: 'en' | 'ar';
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setLanguage: (language: 'en' | 'ar') => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'dark',
      language: 'en',
      setTheme: (theme) => {
        set({ theme });
        document.documentElement.classList.remove('light', 'dark');
        if (theme === 'system') {
          const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
          document.documentElement.classList.add(systemTheme);
        } else {
          document.title = theme;
        }
      },
      setLanguage: (language) => {
        set({ language });
        localStorage.setItem('language', language);
      },
    }),
    {
      name: 'theme-storage',
    }
  )
);

// Favorites Store (local state for quick access, synced with Supabase)
interface FavoritesState {
  favorites: FavoriteItem[];
  addFavorite: (anime: AnimeInfo) => void;
  removeFavorite: (animeId: number) => void;
  setFavorites: (favorites: FavoriteItem[]) => void;
  isFavorite: (animeId: number) => boolean;
}

export const useFavoritesStore = create<FavoritesState>()(
  persist(
    (set, get) => ({
      favorites: [],
      addFavorite: (anime) => {
        const newFavorite: FavoriteItem = {
          id: crypto.randomUUID(),
          anime,
          created_at: new Date().toISOString(),
        };
        return set({ favorites: [...get().favorites, newFavorite] });
      },
      removeFavorite: (animeId) =>
        set({ favorites: get().favorites.filter((f) => f.anime.mal_id !== animeId) }),
      setFavorites: (favorites) => set({ favorites }),
      isFavorite: (animeId) => get().favorites.some((f) => f.anime.mal_id === animeId),
    }),
    {
      name: 'favorites-storage',
    }
  )
);

// Watchlist Store
interface WatchlistState {
  watchlist: WatchlistItem[];
  addToWatchlist: (anime: AnimeInfo, status: WatchlistItem['status']) => void;
  updateWatchlist: (animeId: number, updates: Partial<WatchlistItem>) => void;
  removeFromWatchlist: (animeId: number) => void;
  setWatchlist: (watchlist: WatchlistItem[]) => void;
  getWatchlistItem: (animeId: number) => WatchlistItem | undefined;
  isInWatchlist: (animeId: number) => boolean;
}

export const useWatchlistStore = create<WatchlistState>()(
  persist(
    (set, get) => ({
      watchlist: [],
      addToWatchlist: (anime, status) => {
        const newItem: WatchlistItem = {
          id: crypto.randomUUID(),
          anime,
          status,
          progress: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        return set({ watchlist: [...get().watchlist, newItem] });
      },
      updateWatchlist: (animeId, updates) =>
        set({
          watchlist: get().watchlist.map((item) =>
            item.anime.mal_id === animeId
              ? { ...item, ...updates, updated_at: new Date().toISOString() }
              : item
          ),
        }),
      removeFromWatchlist: (animeId) =>
        set({ watchlist: get().watchlist.filter((item) => item.anime.mal_id !== animeId) }),
      setWatchlist: (watchlist) => set({ watchlist }),
      getWatchlistItem: (animeId) => get().watchlist.find((item) => item.anime.mal_id === animeId),
      isInWatchlist: (animeId) => get().watchlist.some((item) => item.anime.mal_id === animeId),
    }),
    {
      name: 'watchlist-storage',
    }
  )
);

// Watch History Store
interface HistoryState {
  history: HistoryItem[];
  addToHistory: (anime: AnimeInfo, episodeNumber: number, progress: number) => void;
  clearHistory: () => void;
  setHistory: (history: HistoryItem[]) => void;
  getLastWatched: (animeId: number) => HistoryItem | undefined;
}

export const useHistoryStore = create<HistoryState>()(
  persist(
    (set, get) => ({
      history: [],
      addToHistory: (anime, episodeNumber, progress) => {
        const existingIndex = get().history.findIndex(
          (h) => h.anime.mal_id === anime.mal_id && h.episode_number === episodeNumber
        );
        const newItem: HistoryItem = {
          id: crypto.randomUUID(),
          anime,
          episode_number: episodeNumber,
          progress,
          watched_at: new Date().toISOString(),
        };

        if (existingIndex >= 0) {
          set({
            history: get().history.map((item, i) =>
              i === existingIndex ? newItem : item
            ),
          });
        } else {
          set({ history: [newItem, ...get().history.slice(0, 99)] }); // Keep last 100
        }
      },
      clearHistory: () => set({ history: [] }),
      setHistory: (history) => set({ history }),
      getLastWatched: (animeId) => {
        const animeHistory = get().history.filter((h) => h.anime.mal_id === animeId);
        return animeHistory.sort((a, b) =>
          new Date(b.watched_at).getTime() - new Date(a.watched_at).getTime()
        )[0];
      },
    }),
    {
      name: 'history-storage',
    }
  )
);

// User Ratings Store
interface RatingsState {
  ratings: { [animeId: number]: number };
  setRating: (animeId: number, score: number) => void;
  removeRating: (animeId: number) => void;
  setRatings: (ratings: { [animeId: number]: number }) => void;
  getRating: (animeId: number) => number | undefined;
}

export const useRatingsStore = create<RatingsState>()(
  persist(
    (set, get) => ({
      ratings: {},
      setRating: (animeId, score) =>
        set({ ratings: { ...get().ratings, [animeId]: score } }),
      removeRating: (animeId) => {
        const newRatings = { ...get().ratings };
        delete newRatings[animeId];
        set({ ratings: newRatings });
      },
      setRatings: (ratings) => set({ ratings }),
      getRating: (animeId) => get().ratings[animeId],
    }),
    {
      name: 'ratings-storage',
    }
  )
);

// UI Store
interface UIState {
  sidebarOpen: boolean;
  searchOpen: boolean;
  toggleSidebar: () => void;
  toggleSearch: () => void;
}

export const useUIStore = create<UIState>()((set) => ({
  sidebarOpen: false,
  searchOpen: false,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  toggleSearch: () => set((state) => ({ searchOpen: !state.searchOpen })),
}));
