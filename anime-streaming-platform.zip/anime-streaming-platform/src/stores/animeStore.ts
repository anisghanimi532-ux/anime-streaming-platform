// src/stores/animeStore.ts
import { create } from 'zustand';
import type { Anime, UserAnimeStatus } from '../types/anime';

interface AnimeState {
  // Current anime data
  currentAnime: Anime | null;
  setCurrentAnime: (anime: Anime | null) => void;

  // User anime list
  animeList: UserAnimeStatus[];
  setAnimeList: (list: UserAnimeStatus[]) => void;
  addToList: (item: UserAnimeStatus) => void;
  updateListItem: (animeId: number, updates: Partial<UserAnimeStatus>) => void;
  removeFromList: (animeId: number) => void;

  // Favorites
  favorites: Anime[];
  setFavorites: (favorites: Anime[]) => void;
  addToFavorites: (anime: Anime) => void;
  removeFromFavorites: (animeId: number) => void;
  isFavorite: (animeId: number) => boolean;

  // Continue watching
  continueWatching: UserAnimeStatus[];
  setContinueWatching: (items: UserAnimeStatus[]) => void;

  // Search history
  searchHistory: string[];
  addToSearchHistory: (query: string) => void;
  clearSearchHistory: () => void;

  // Video player state
  currentEpisode: number;
  setCurrentEpisode: (episode: number) => void;
}

export const useAnimeStore = create<AnimeState>((set, get) => ({
  currentAnime: null,
  setCurrentAnime: (anime) => set({ currentAnime: anime }),

  animeList: [],
  setAnimeList: (list) => set({ animeList: list }),
  addToList: (item) => set({ animeList: [...get().animeList, item] }),
  updateListItem: (animeId, updates) =>
    set({
      animeList: get().animeList.map((item) =>
        item.anime_id === animeId ? { ...item, ...updates } : item
      ),
    }),
  removeFromList: (animeId) =>
    set({
      animeList: get().animeList.filter((item) => item.anime_id !== animeId),
    }),

  favorites: [],
  setFavorites: (favorites) => set({ favorites }),
  addToFavorites: (anime) => set({ favorites: [...get().favorites, anime] }),
  removeFromFavorites: (animeId) =>
    set({
      favorites: get().favorites.filter((a) => a.mal_id !== animeId),
    }),
  isFavorite: (animeId) => get().favorites.some((a) => a.mal_id === animeId),

  continueWatching: [],
  setContinueWatching: (items) => set({ continueWatching: items }),

  searchHistory: [],
  addToSearchHistory: (query) => {
    const history = get().searchHistory.filter((q) => q !== query);
    set({ searchHistory: [query, ...history].slice(0, 10) });
  },
  clearSearchHistory: () => set({ searchHistory: [] }),

  currentEpisode: 1,
  setCurrentEpisode: (episode) => set({ currentEpisode: episode }),
}));