// src/types/anime.ts

export interface Anime {
  mal_id: number;
  title: string;
  title_english?: string | null;
  title_japanese?: string;
  images: {
    jpg: {
      image_url: string;
      large_image_url: string;
      maximum_image_url?: string;
    };
    webp?: {
      image_url: string;
      large_image_url: string;
      maximum_image_url?: string;
    };
  };
  synopsis?: string;
  type?: string;
  source?: string;
  episodes?: number;
  status?: string;
  airing?: boolean;
  aired: {
    from?: string;
    to?: string;
    string?: string;
  };
  duration?: string;
  rating?: string;
  score?: number;
  scored_by?: number;
  rank?: number;
  popularity?: number;
  members?: number;
  favorites?: number;
  studios: Array<{ mal_id: number; name: string; type: string }>;
  producers: Array<{ mal_id: number; name: string; type: string }>;
  genres: Array<{ mal_id: number; name: string; type: string }>;
  themes: Array<{ mal_id: number; name: string; type: string }>;
  demographics: Array<{ mal_id: number; name: string; type: string }>;
  season?: string;
  year?: number;
  broadcast?: {
    day?: string;
    time?: string;
    timezone?: string;
    string?: string;
  };
  relations?: Array<{
    relation: string;
    entry: Array<{
      mal_id: number;
      type: string;
      name: string;
      url: string;
    }>;
  }>;
  trailer?: {
    youtube_id?: string;
    url?: string;
    embed_url?: string;
  };
}

export interface Episode {
  mal_id: number;
  anime_id: number;
  episode: number;
  title?: string;
  title_japanese?: string;
  title_romanji?: string;
  aired?: string;
  filler?: boolean;
  recap?: boolean;
  score?: number;
}

export interface Genre {
  mal_id: number;
  name: string;
  url: string;
  count: number;
}

export interface Season {
  year: number;
  seasons: string[];
}

export interface UserAnimeStatus {
  id?: number;
  user_id: string;
  anime_id: number;
  anime_title: string;
  anime_image: string;
  status: 'watching' | 'completed' | 'on_hold' | 'dropped' | 'plan_to_watch';
  score?: number;
  episodes_watched: number;
  start_date?: string;
  finish_date?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Comment {
  id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  anime_id: number;
  episode_number?: number;
  content: string;
  likes: number;
  created_at: string;
  parent_id?: string;
}

export interface User {
  id: string;
  email: string;
  username: string;
  avatar_url?: string;
  created_at: string;
}