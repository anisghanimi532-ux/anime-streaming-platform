// src/App.tsx
import { Routes, Route } from 'react-router-dom';
import { useThemeStore } from './stores/themeStore';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

// Layout
import Layout from './components/layout/Layout';

// Pages
import HomePage from './pages/HomePage';
import AnimeListPage from './pages/AnimeListPage';
import AnimeDetailPage from './pages/AnimeDetailPage';
import WatchPage from './pages/WatchPage';
import SearchPage from './pages/SearchPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ProfilePage from './pages/ProfilePage';
import MyListPage from './pages/MyListPage';
import FavoritesPage from './pages/FavoritesPage';
import HistoryPage from './pages/HistoryPage';
import MoviesPage from './pages/MoviesPage';
import NewEpisodesPage from './pages/NewEpisodesPage';

function App() {
  const { theme } = useThemeStore();
  const { i18n } = useTranslation();

  useEffect(() => {
    // Apply theme
    document.documentElement.classList.remove('dark', 'light');
    document.documentElement.classList.add(theme);
  }, [theme]);

  useEffect(() => {
    // Apply language direction
    const lang = i18n.language;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [i18n.language]);

  return (
    <div className="min-h-screen bg-[var(--color-bg)]">
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="anime" element={<AnimeListPage />} />
          <Route path="anime/:id" element={<AnimeDetailPage />} />
          <Route path="watch/:id/:episode" element={<WatchPage />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="movies" element={<MoviesPage />} />
          <Route path="new-episodes" element={<NewEpisodesPage />} />
          <Route path="my-list" element={<MyListPage />} />
          <Route path="favorites" element={<FavoritesPage />} />
          <Route path="history" element={<HistoryPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Routes>
    </div>
  );
}

export default App;